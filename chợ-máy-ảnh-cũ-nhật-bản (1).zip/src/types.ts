export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  category: "Máy Ảnh" | "Ống Kính" | "Phụ Kiện";
  subcategory: string;
  description: string;
  images: string[];
  sizes: string[];
  colors: { name: string; code: string }[];
  seoTitle?: string;
  seoDescription?: string;
  seoKeywords?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CartItem {
  id: string; // Composite key like productId-color-size
  product: Product;
  selectedColor: { name: string; code: string };
  selectedSize: string;
  quantity: number;
}

export interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerAddress: string;
  items: {
    productId: string;
    name: string;
    price: number;
    quantity: number;
    color: string;
    size: string;
    image: string;
  }[];
  totalAmount: number;
  status: "Chờ xử lý" | "Đã xác nhận" | "Đang giao" | "Đã hoàn thành" | "Đã hủy";
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: "customer" | "admin";
  createdAt: string;
}

