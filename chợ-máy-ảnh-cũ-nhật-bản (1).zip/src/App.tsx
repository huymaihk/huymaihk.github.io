import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import ProductCard from './components/ProductCard';
import ProductDetailModal from './components/ProductDetailModal';
import CartDrawer from './components/CartDrawer';
import AdminPanel from './components/AdminPanel';
import AuthModal from './components/AuthModal';
import { Product, CartItem, User } from './types';
import { getLiveProducts, isFirebaseEnabled, getSessionUser, logoutUser } from './firebase';
import { Sparkles, ArrowRight, ShieldAlert, BadgeInfo, CheckCircle, Flame } from 'lucide-react';

export default function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [activeCategory, setActiveCategory] = useState<"Tất cả" | "Máy Ảnh" | "Ống Kính" | "Phụ Kiện">("Tất cả");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Shopping Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  
  // Custom auth states
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authInitialTab, setAuthInitialTab] = useState<"login" | "register">("login");

  // View mode
  const [isAdminMode, setIsAdminMode] = useState(false);
  
  // Catalog loader
  const [isLoading, setIsLoading] = useState(true);

  // Load products on start
  useEffect(() => {
    loadCatalog();

    // Check user authentication status from storage
    const savedUser = getSessionUser();
    if (savedUser) {
      setCurrentUser(savedUser);
    }

    // Recover shopping cart from local storage 
    const storedCart = localStorage.getItem("camera_user_cart");
    if (storedCart) {
      try {
        setCartItems(JSON.parse(storedCart));
      } catch (e) {
        console.error("Cart retrieval failed", e);
      }
    }
  }, []);

  const loadCatalog = async () => {
    setIsLoading(true);
    try {
      const items = await getLiveProducts();
      setProducts(items);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    await logoutUser();
    setCurrentUser(null);
    setIsAdminMode(false);
  };

  // Add item to cart action
  const handleAddToCart = (info: Omit<CartItem, "id">) => {
    const compositeId = `${info.product.id}-${info.selectedColor.name}-${info.selectedSize}`;
    
    // Check if duplicate exists
    const existingIdx = cartItems.findIndex(item => item.id === compositeId);
    let updatedCart: CartItem[] = [];

    if (existingIdx > -1) {
      // Is duplicate, increment quantity
      updatedCart = [...cartItems];
      updatedCart[existingIdx].quantity += info.quantity;
    } else {
      // Insert new line item
      updatedCart = [...cartItems, { ...info, id: compositeId }];
    }

    setCartItems(updatedCart);
    localStorage.setItem("camera_user_cart", JSON.stringify(updatedCart));
  };

  // Update item quantity in cart
  const handleUpdateCartQuantity = (id: string, delta: number) => {
    const updated = cartItems.map(item => {
      if (item.id === id) {
        const newQty = item.quantity + delta;
        return newQty > 0 ? { ...item, quantity: newQty } : null;
      }
      return item;
    }).filter((item): item is CartItem => item !== null);

    setCartItems(updated);
    localStorage.setItem("camera_user_cart", JSON.stringify(updated));
  };

  // Remove item entirely
  const handleRemoveCartItem = (id: string) => {
    const updated = cartItems.filter(item => item.id !== id);
    setCartItems(updated);
    localStorage.setItem("camera_user_cart", JSON.stringify(updated));
  };

  // Empty cart helper
  const handleClearCart = () => {
    setCartItems([]);
    localStorage.removeItem("camera_user_cart");
  };

  // Filter products by category and search
  const getFilteredProducts = () => {
    return products.filter(prod => {
      // Category query match
      const categoryMatch = activeCategory === "Tất cả" || prod.category === activeCategory;
      
      // Search query terms match
      const nameMatch = prod.name.toLowerCase().includes(searchQuery.toLowerCase());
      const subcatMatch = (prod.subcategory || "").toLowerCase().includes(searchQuery.toLowerCase());
      const descMatch = prod.description.toLowerCase().includes(searchQuery.toLowerCase());
      const tagMatch = (prod.seoKeywords || "").toLowerCase().includes(searchQuery.toLowerCase());

      return categoryMatch && (nameMatch || subcatMatch || descMatch || tagMatch);
    });
  };

  const filteredProducts = getFilteredProducts();
  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#FAFAFA] flex flex-col font-sans text-gray-900 overflow-x-hidden" id="uniqlo-root">
      
      {/* Header element */}
      <Header
        activeCategory={activeCategory}
        setActiveCategory={(cat) => { setActiveCategory(cat); setIsAdminMode(false); }}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        cartCount={cartCount}
        onOpenCart={() => setIsCartOpen(true)}
        isAdminMode={isAdminMode}
        setIsAdminMode={setIsAdminMode}
        isFirebaseEnabled={isFirebaseEnabled}
        currentUser={currentUser}
        onOpenAuthModal={(tab) => { setAuthInitialTab(tab || "login"); setIsAuthModalOpen(true); }}
        onLogout={handleLogout}
      />

      {/* Main viewport */}
      <main className="flex-grow">
        
        {isAdminMode ? (
          /* Render the custom merchant system dashboard if Admin Toggle is activated */
          <AdminPanel 
            products={products} 
            onRefreshProducts={loadCatalog} 
            isAdminMode={isAdminMode} 
          />
        ) : (
          /* Render shopper storefront */
          <div id="store-frontpage-view" className="animate-fade-in">
            
            {/* Visual Seasonal Promo Banner Cards Carousel */}
            <section className="bg-white border-b border-gray-100 py-6 md:py-10">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                
                {/* Master Campaign Jumbotron */}
                <div className="bg-red-50/50 border-r-4 border-l-4 border-[#E60012] p-4 sm:p-6 mb-8 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-[#E60012] text-white rounded-sm shrink-0">
                      <Flame className="w-5 h-5 animate-pulse" />
                    </div>
                    <div>
                      <h2 className="text-sm md:text-base font-black text-gray-900 tracking-tight">SIÊU THỊ MÁY ẢNH CŨ & LENS NHẬT BẢN CHÍNH HÃNG 2026</h2>
                      <p className="text-xs text-gray-500 mt-0.5">Duy nhất tuần này: Tặng kèm thẻ nhớ cao tốc 64GB và túi chống sốc khi mua bất kì dòng máy ảnh DSLR/Mirrorless nào.</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => {
                      const sampleProduct = products.find(p => p.originalPrice);
                      if (sampleProduct) setSelectedProduct(sampleProduct);
                    }}
                    className="bg-[#E60012] hover:bg-black text-white text-xs font-black px-4 py-2.5 uppercase tracking-wider flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer"
                  >
                    MUA NGAY <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Sub features catalog selectors */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  
                  {/* Feature Box 1 */}
                  <div className="border border-gray-200 group overflow-hidden flex flex-col bg-white">
                    <div className="aspect-16/9 bg-gray-100 overflow-hidden relative">
                      <img 
                        src="https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=500&q=80" 
                        alt="DSLR Mirrorless lướt" 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-black/25 flex flex-col justify-end p-4 text-white">
                        <span className="bg-white text-gray-900 font-extrabold text-[9px] px-2 py-0.5 w-max tracking-wider uppercase mb-1">MÁY ẢNH CHUYÊN NGHIỆP</span>
                        <h3 className="text-sm font-black tracking-wide leading-none uppercase">DSLR & Mirrorless lướt</h3>
                      </div>
                    </div>
                    <div className="p-3 bg-white flex justify-between items-center text-xs">
                      <span className="text-gray-500 font-medium">Nguyên bản Nhật Bản, kiểm tra shot kỹ càng.</span>
                      <button 
                        onClick={() => { setSearchQuery("Máy Ảnh"); setActiveCategory("Máy Ảnh"); }} 
                        className="text-[#E60012] font-bold flex items-center gap-0.5 hover:underline"
                      >
                        Xem <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Feature Box 2 */}
                  <div className="border border-gray-200 group overflow-hidden flex flex-col bg-white">
                    <div className="aspect-16/9 bg-gray-100 overflow-hidden relative">
                      <img 
                        src="https://images.unsplash.com/photo-1617005082133-548c4dd27f35?auto=format&fit=crop&w=500&q=80" 
                        alt="Ống Kính (Lenses)" 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-black/25 flex flex-col justify-end p-4 text-white">
                        <span className="bg-white text-gray-900 font-extrabold text-[9px] px-2 py-0.5 w-max tracking-wider uppercase mb-1">ỐNG KÍNH QUANG HỌC</span>
                        <h3 className="text-sm font-black tracking-wide leading-none uppercase">Lenses Ngoại Hình Đẹp</h3>
                      </div>
                    </div>
                    <div className="p-3 bg-white flex justify-between items-center text-xs">
                      <span className="text-gray-500 font-medium font-bold text-green-700">Kính đẹp trơn tru, không mốc rễ tre.</span>
                      <button 
                        onClick={() => { setSearchQuery("Ống Kính"); setActiveCategory("Ống Kính"); }} 
                        className="text-[#E60012] font-bold flex items-center gap-0.5 hover:underline"
                      >
                        Xem <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Feature Box 3 */}
                  <div className="border border-gray-200 group overflow-hidden flex flex-col bg-white">
                    <div className="aspect-16/9 bg-gray-100 overflow-hidden relative">
                      <img 
                        src="https://images.unsplash.com/photo-1542038784456-1ea8e935640e?auto=format&fit=crop&w=500&q=80" 
                        alt="Phụ kiện nhiếp ảnh" 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-black/25 flex flex-col justify-end p-4 text-white">
                        <span className="bg-white text-gray-900 font-extrabold text-[9px] px-2 py-0.5 w-max tracking-wider uppercase mb-1">PHỤ KIỆN GEEKS</span>
                        <h3 className="text-sm font-black tracking-wide leading-none uppercase">Đầu đọc, sạc, chân máy</h3>
                      </div>
                    </div>
                    <div className="p-3 bg-white flex justify-between items-center text-xs">
                      <span className="text-gray-500 font-medium">Đảm bảo pin dung lượng chuẩn, chân chắc chắn.</span>
                      <button 
                        onClick={() => { setSearchQuery("Phụ Kiện"); setActiveCategory("Phụ Kiện"); }} 
                        className="text-[#E60012] font-bold flex items-center gap-0.5 hover:underline"
                      >
                        Xem <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                </div>

              </div>
            </section>

            {/* Core Product Grid section */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" id="store-apparel-grid">
              
              {/* Grid Header and Quick Reset Filters */}
              <div className="flex justify-between items-baseline mb-6 border-b border-gray-200 pb-3">
                <h2 className="text-sm md:text-base font-extrabold text-gray-900 tracking-wider uppercase flex items-center gap-2">
                  <span>Trưng bày: {activeCategory === "Tất cả" ? "TẤT CẢ SẢN PHẨM" : activeCategory}</span>
                  <span className="text-xs text-gray-400 font-normal">({filteredProducts.length} loại)</span>
                </h2>

                {(searchQuery || activeCategory !== "Tất cả") && (
                  <button
                    onClick={() => { setSearchQuery(""); setActiveCategory("Tất cả"); }}
                    className="text-xs text-[#E60012] font-bold hover:underline"
                  >
                    Xóa các bộ lọc tìm kiếm
                  </button>
                )}
              </div>

              {/* Loader Spinner */}
              {isLoading ? (
                <div className="text-center py-20">
                  <div className="inline-block w-8 h-8 border-4 border-red-200 border-t-red-600 rounded-full animate-spin"></div>
                  <p className="text-xs text-gray-500 mt-2 font-medium">Đang tải danh sách máy ảnh & ống kính mới nhất...</p>
                </div>
              ) : (
                /* Main product cards grid array */
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                  {filteredProducts.map((prod) => (
                    <ProductCard
                      key={prod.id}
                      product={prod}
                      onSelect={(p) => setSelectedProduct(p)}
                    />
                  ))}
                </div>
              )}

              {/* No items matching handler */}
              {!isLoading && filteredProducts.length === 0 && (
                <div className="text-center py-24 bg-white border border-gray-200 p-8">
                  <BadgeInfo className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-sm font-extrabold text-gray-600">Không tìm thấy thiết bị cần tìm</p>
                  <p className="text-xs text-gray-400 mt-1 max-w-sm mx-auto">Thử gõ một thương hiệu hoặc từ khóa khác như "Sony", "Canon", "Nikon", "Fujifilm" hoặc thay đổi danh mục nhé!</p>
                  <button
                    onClick={() => { setSearchQuery(""); setActiveCategory("Tất cả"); }}
                    className="mt-6 bg-[#E60012] text-white font-extrabold text-xs py-2 px-4 uppercase"
                  >
                    Trở lại tất cả sản phẩm
                  </button>
                </div>
              )}

            </section>

            {/* Floating Alert hint for terms when isFirebaseEnabled is false */}
            {!isFirebaseEnabled && (
              <section className="bg-amber-50 border-t border-b border-amber-200 text-amber-900 py-3 px-4 text-xs text-center">
                <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-center items-center gap-1.5">
                  <span className="font-bold">✨ Gợi ý cho bạn:</span>
                  <span>Hãy nhấn chấp nhận điều khoản Firebase trong UI để kích hoạt bền bỉ cơ sở dữ liệu Cloud Firestore!</span>
                </div>
              </section>
            )}

          </div>
        )}

      </main>

      {/* Shared Footer block */}
      <footer className="bg-gray-150 border-t border-gray-200 text-xs py-10" id="uniqlo-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8 mb-6">
          <div className="space-y-2">
            <div className="bg-black text-white font-black text-xs w-max p-2 tracking-tighter uppercase">CHỢ MÁY ẢNH CŨ</div>
            <p className="text-gray-500 leading-relaxed font-sans">
              Hệ thống cung cấp và thẩm định thiết bị nhiếp ảnh lướt, máy ảnh, ống kính chính hãng nhập khẩu từ Nhật Bản. Bảo hành 12 tháng chuyên nghiệp.
            </p>
          </div>
          <div>
            <h4 className="font-extrabold text-gray-800 uppercase mb-3">Danh mục máy cũ</h4>
            <ul className="space-y-1.5 text-gray-500 leading-normal">
              <li><a href="#" onClick={() => { setActiveCategory("Máy Ảnh"); }} className="hover:text-black">Máy ảnh DSLR & Mirrorless</a></li>
              <li><a href="#" onClick={() => { setActiveCategory("Ống Kính"); }} className="hover:text-black">Ống Kính Cao Cấp</a></li>
              <li><a href="#" onClick={() => { setActiveCategory("Phụ Kiện"); }} className="hover:text-black">Phụ kiện nhiếp ảnh</a></li>
              <li><a href="#" className="hover:text-black">Dòng máy Vintage / Retro</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-extrabold text-gray-800 uppercase mb-3 text-gray-800">Cam kết chất lượng</h4>
            <ul className="space-y-1.5 text-gray-500 leading-normal">
              <li><a href="#" className="hover:text-black">Bảo hành 1 đổi 1 trong 7 ngày</a></li>
              <li><a href="#" className="hover:text-black">Quy trình test số shot nghiêm ngặt</a></li>
              <li><a href="#" className="hover:text-black">Giao hàng và đồng kiểm COD toàn quốc</a></li>
              <li><a href="#" className="hover:text-black">Hỗ trợ trọn đời máy</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-extrabold text-[#E60012] uppercase mb-3 flex items-center gap-1">
              <ShieldAlert className="w-4 h-4" /> TRANG QUẢN TRỊ OWNER
            </h4>
            <p className="text-gray-500 leading-relaxed mb-3">
              Chủ cửa hàng hoặc quản trị viên có thể truy cập Bảng quản trị để thực hiện Đăng sản phẩm máy ảnh và Duyệt đơn hàng tức thời.
            </p>
            <button
              id="footer-admin-link"
              onClick={() => { setIsAdminMode(true); window.scrollTo({ top: 0, behavior: "smooth" }); }}
              className="bg-gray-900 text-white font-extrabold text-[11px] px-3.5 py-2 uppercase tracking-wider flex items-center gap-1 cursor-pointer hover:bg-black"
            >
              Vào Trang Admin
            </button>
          </div>
        </div>
        <div className="border-t border-gray-200 pt-6 text-center text-gray-400">
          <p>© 2026 Chợ Máy Ảnh Cũ Nhật Bản Applet Vietnam. Thiết bị bền bỉ - Gửi trọn niềm tin nhiếp ảnh.</p>
        </div>
      </footer>

      {/* --- Dynamic Floating Layover Modals --- */}

      {/* 1. Immersive Product details modal view */}
      {selectedProduct && (
        <ProductDetailModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={handleAddToCart}
        />
      )}

      {/* 2. Side drawer checkout panel */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
      />

      {/* User Authentication modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAuthSuccess={(user) => {
          setCurrentUser(user);
          if (user.role === "admin") {
            setIsAdminMode(true);
          }
        }}
        initialTab={authInitialTab}
      />

      {/* 3. Global Floating Success Add-To-Cart Notification card */}
      <div
        id="cart-confirm-toast"
        className="fixed bottom-6 right-6 z-50 bg-gray-900 border border-gray-800 text-white text-xs py-3.5 px-5 shadow-2xl flex items-center gap-3 transition-all duration-300 translate-y-20 opacity-0"
      >
        <CheckCircle className="w-5 h-5 text-green-400 shrink-0" />
        <div>
          <p className="font-extrabold tracking-wide uppercase">Thành công!</p>
          <p className="text-gray-300 text-[10px] mt-0.5">Sản phẩm tuyệt vời đã được xếp trực tiếp vào giỏ hàng.</p>
        </div>
      </div>

    </div>
  );
}
