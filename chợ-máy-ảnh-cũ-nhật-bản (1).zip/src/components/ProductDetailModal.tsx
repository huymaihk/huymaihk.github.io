import React, { useState, useEffect } from 'react';
import { Product, CartItem } from '../types';
import { X, Plus, Minus, ShoppingBag, Check, Search, Percent, Info, Sparkles } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (item: Omit<CartItem, "id">) => void;
}

export default function ProductDetailModal({ product, onClose, onAddToCart }: ProductDetailModalProps) {
  const [selectedSize, setSelectedSize] = useState<string>("");
  const [selectedColor, setSelectedColor] = useState<{ name: string; code: string } | null>(null);
  const [quantity, setQuantity] = useState<number>(1);
  const [errorMsg, setErrorMsg] = useState<string>("");
  const [activeImage, setActiveImage] = useState<string>("");

  useEffect(() => {
    if (product) {
      if (product.sizes && product.sizes.length > 0) {
        setSelectedSize(product.sizes[0]);
      }
      if (product.colors && product.colors.length > 0) {
        setSelectedColor(product.colors[0]);
      } else {
        setSelectedColor({ name: "Tiêu chuẩn", code: "#CCCCCC" });
      }
      if (product.images && product.images.length > 0) {
        setActiveImage(product.images[0]);
      }
    }
    setQuantity(1);
    setErrorMsg("");
  }, [product]);

  const handleDecrease = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const handleIncrease = () => {
    setQuantity(quantity + 1);
  };

  const handleAdd = () => {
    if (!selectedSize) {
      setErrorMsg("Vui lòng chọn một kích cỡ trước khi thêm vào giỏ.");
      return;
    }
    if (!selectedColor) {
      setErrorMsg("Vui lòng chọn màu sắc trước khi thêm.");
      return;
    }

    onAddToCart({
      product,
      selectedSize,
      selectedColor,
      quantity
    });

    // Simple confirmation success toast mock
    const confirmAlert = document.getElementById("cart-confirm-toast");
    if (confirmAlert) {
      confirmAlert.classList.remove("translate-y-20", "opacity-0");
      setTimeout(() => {
        confirmAlert.classList.add("translate-y-20", "opacity-0");
      }, 2500);
    }
    onClose();
  };

  const formatPrice = (value: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value);
  };

  // Safe defaults for metadata
  const calculatedSeoTitle = product.seoTitle || `${product.name} | Thời Trang Chất Lượng UNIQLO`;
  const calculatedSeoDesc = product.seoDescription || `${product.name} chính hãng Uniqlo Vietnam. Thiết kế triết lý LifeWear bền bỉ tối giản, co giãn vô cùng thoáng mát. Giao hàng toàn quốc nhanh chóng.`;
  const calculatedSeoKeywords = product.seoKeywords || `uniqlo viet nam, uniqlo, ${product.name.toLowerCase()}`;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        
        {/* Background gray blanket */}
        <div 
          onClick={onClose} 
          className="fixed inset-0 bg-black/60 transition-opacity backdrop-blur-xs" 
          aria-hidden="true"
        />

        {/* Browser viewport align trick */}
        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        <div className="inline-block align-bottom bg-white rounded-none border border-gray-100 text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl sm:w-full">
          
          {/* Header Actions */}
          <div className="absolute top-4 right-4 z-10">
            <button
              id="close-modal-btn"
              onClick={onClose}
              className="p-1.5 rounded-full bg-white/70 hover:bg-gray-200 text-gray-500 hover:text-black transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-4 md:p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              
              {/* Product Visual Gallery */}
              <div className="flex flex-col gap-3">
                <div className="aspect-4/5 w-full bg-gray-50 border border-gray-200 overflow-hidden relative">
                  <img
                    src={activeImage || "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=500&q=80"}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center"
                  />
                  
                  {product.originalPrice && product.originalPrice > product.price && (
                    <div className="absolute top-3 left-3 bg-[#E60012] text-white font-bold text-xs px-2.5 py-1 flex items-center gap-1 rounded-sm">
                      <Percent className="w-3.5 h-3.5" /> ƯU ĐÃI LỚN
                    </div>
                  )}
                </div>

                {/* Multiple Images Carousel List */}
                {product.images && product.images.length > 1 && (
                  <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
                    {product.images.map((imgUrl, i) => (
                      <button
                        key={`${imgUrl}-${i}`}
                        onClick={() => setActiveImage(imgUrl)}
                        className={`w-16 h-16 border bg-gray-50 overflow-hidden shrink-0 transition-opacity ${
                          activeImage === imgUrl ? "border-[#E60012] opacity-100" : "border-gray-200 opacity-60 hover:opacity-90"
                        }`}
                      >
                        <img src={imgUrl} alt="Thumbnail" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Product Information Form Column */}
              <div className="flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold text-gray-400 bg-gray-100 px-2 py-1 select-none">
                    UNIQLO Vietnam - {product.category}
                  </span>
                  
                  <h1 className="text-sm md:text-xl font-extrabold text-gray-900 mt-2 mb-1 tracking-tight">
                    {product.name}
                  </h1>

                  <p className="text-xs text-gray-400 mb-4 tracking-wider uppercase font-medium">
                    Mã sản phẩm: SKU-{product.id.split('_').pop() || "UQL01"}
                  </p>

                  {/* Pricing block */}
                  <div className="flex items-baseline gap-3 mb-6 bg-red-50/40 p-3 border border-red-100">
                    <span className="text-xl md:text-2xl font-black text-[#E60012]">
                      {formatPrice(product.price)}
                    </span>
                    {product.originalPrice && product.originalPrice > product.price && (
                      <span className="text-sm text-gray-400 line-through">
                        {formatPrice(product.originalPrice)}
                      </span>
                    )}
                  </div>

                  {/* Colors selector */}
                  <div className="mb-4">
                    <h3 className="text-xs font-bold text-gray-800 tracking-wide uppercase mb-2">
                      Màu Sắc: <span className="text-gray-500 font-normal">{selectedColor?.name}</span>
                    </h3>
                    <div className="flex flex-wrap gap-2.5">
                      {product.colors && product.colors.map((color, idx) => (
                        <button
                          key={`${color.name}-${idx}`}
                          onClick={() => setSelectedColor(color)}
                          className={`w-7 h-7 border text-[10px] rounded-full flex items-center justify-center relative ring-offset-2 transition-all cursor-pointer ${
                            selectedColor?.name === color.name 
                              ? "ring-2 ring-[#E60012] border-transparent" 
                              : "border-gray-300 hover:scale-105"
                          }`}
                          style={{ backgroundColor: color.code }}
                          title={color.name}
                        >
                          {selectedColor?.name === color.name && (
                            <Check className={`w-4 h-4 ${color.code === '#FFFFFF' || color.code === '#FFFBEB' || color.code === '#F5F5F4' ? 'text-black' : 'text-white'}`} />
                          )}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Sizes selector */}
                  <div className="mb-6">
                    <h3 className="text-xs font-bold text-gray-800 tracking-wide uppercase mb-2">
                      Chọn Kích Cỡ:
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {product.sizes && product.sizes.map((sz) => (
                        <button
                          key={sz}
                          onClick={() => setSelectedSize(sz)}
                          className={`px-3 py-1.5 border text-xs font-bold transition-all cursor-pointer ${
                            selectedSize === sz
                              ? "bg-gray-900 border-gray-900 text-white"
                              : "border-gray-200 text-gray-700 bg-white hover:bg-gray-50"
                          }`}
                        >
                          {sz}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Quantity and Checkout interaction bar */}
                  <div className="flex items-center gap-4 py-4 border-t border-b border-gray-100 mb-6">
                    <span className="text-xs font-bold text-gray-600 uppercase">Số lượng:</span>
                    <div className="flex items-center border border-gray-300 rounded overflow-hidden">
                      <button
                        onClick={handleDecrease}
                        className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-600 transition-colors"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-5 text-sm font-extrabold text-gray-800 select-none">
                        {quantity}
                      </span>
                      <button
                        onClick={handleIncrease}
                        className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-600 transition-colors"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {errorMsg && (
                    <p className="text-xs text-red-500 font-semibold mb-4 bg-red-50 p-2 border-l-4 border-red-500">
                      {errorMsg}
                    </p>
                  )}

                  {/* Action Purchase triggers */}
                  <button
                    onClick={handleAdd}
                    className="w-full bg-[#E60012] hover:bg-red-700 text-white font-extrabold text-sm py-4 tracking-widest uppercase transition-colors flex items-center justify-center gap-2.5 shadow-sm cursor-pointer"
                  >
                    <ShoppingBag className="w-4 h-4" /> Thêm vào túi đồ
                  </button>
                </div>
              </div>

            </div>

            {/* Immersive technical specifications and Uniqlo Description below */}
            <div className="mt-10 border-t border-gray-200 pt-8">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
                
                {/* Product Description */}
                <div className="md:col-span-7">
                  <h2 className="text-sm font-black text-gray-900 tracking-wider uppercase mb-3 pb-2 border-b border-gray-300">
                    Chi tiết sản phẩm / Công nghệ LifeWear
                  </h2>
                  <div className="text-xs md:text-sm text-gray-700 leading-relaxed space-y-3 whitespace-pre-wrap font-sans">
                    {product.description}
                  </div>
                </div>

                {/* Simulated Google Search SEO Box Preview! */}
                <div className="md:col-span-5 bg-gray-50 border border-gray-200 p-4 rounded-sm">
                  <h2 className="text-xs font-black text-gray-900 tracking-wider uppercase mb-4 flex items-center gap-1">
                    <Search className="w-4 h-4 text-blue-500" /> Bản xem trước kết quả Google (SEO)
                  </h2>
                  
                  {/* Styled like standard Google search result card snippet */}
                  <div className="bg-white border border-gray-200 p-3.5 shadow-xs font-sans rounded-sm">
                    <div className="flex items-center gap-1.5 text-[11px] text-gray-500 mb-1 overflow-hidden whitespace-nowrap text-ellipsis">
                      <span className="font-semibold text-gray-700">uniqlo.com</span>
                      <span>› vn › vi › products › {product.id}</span>
                    </div>
                    
                    <a href="#" className="font-medium text-[15px] text-blue-800 hover:underline leading-tight block mb-1">
                      {calculatedSeoTitle}
                    </a>
                    
                    <p className="text-[12px] text-gray-600 leading-relaxed mb-2 line-clamp-3">
                      {calculatedSeoDesc}
                    </p>

                    <div className="flex flex-wrap gap-1 text-[10px] text-gray-500 border-t border-gray-100 pt-2">
                      <span className="font-bold text-gray-700">Dùng từ khóa:</span>
                      <span>{calculatedSeoKeywords}</span>
                    </div>
                  </div>

                  <div className="mt-3.5 flex items-start gap-1.5 text-[10px] text-gray-500 leading-normal">
                    <Info className="w-4 h-4 text-[#E60012] shrink-0" />
                    <span>
                      SEO Snippet này được chủ cửa hàng sinh ra tự động cực nhanh bằng **Trí Tuệ Nhân Tạo Gemini AI** trong trang quản lý. Thẻ tiêu đề và thẻ mô tả tối ưu hóa việc phân hạng của Google!
                    </span>
                  </div>
                </div>

              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
