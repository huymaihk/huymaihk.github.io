import React from 'react';
import { Product } from '../types';
import { Eye, Percent } from 'lucide-react';

interface ProductCardProps {
  key?: string;
  product: Product;
  onSelect: (product: Product) => void;
}

export default function ProductCard({ product, onSelect }: ProductCardProps) {
  // Format price helper
  const formatPrice = (value: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value);
  };

  // Calculate discount percentage if original price lies there
  const getDiscount = () => {
    if (product.originalPrice && product.originalPrice > product.price) {
      const reduction = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
      return reduction > 0 ? `${reduction}%` : null;
    }
    return null;
  };

  const discountVal = getDiscount();

  return (
    <div
      id={`product-card-${product.id}`}
      className="group bg-white border border-gray-200 overflow-hidden flex flex-col transition-all duration-300 hover:shadow-md cursor-pointer h-full relative"
      onClick={() => onSelect(product)}
    >
      {/* Upper apparel visual container */}
      <div className="relative aspect-4/5 w-full bg-gray-50 overflow-hidden">
        <img
          src={product.images[0] || "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=500&q=80"}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
        />

        {/* Hover Quick View overlay */}
        <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <span className="bg-white/95 text-gray-900 border border-gray-200 text-xs font-bold py-2 px-4 shadow-sm flex items-center gap-1.5 transition-transform duration-300 translate-y-3 group-hover:translate-y-0">
            <Eye className="w-4 h-4 text-[#E60012]" /> Xem chi tiết
          </span>
        </div>

        {/* Categories / Badges overlay */}
        <div className="absolute top-2 left-2 flex flex-col gap-1 z-10">
          <span className="bg-gray-900/80 text-white text-[10px] font-bold tracking-wide px-2 py-0.5 uppercase">
            {product.category}
          </span>
          {discountVal && (
            <span className="bg-[#E60012] text-white text-[10px] font-bold px-2 py-0.5 flex items-center gap-0.5 shrink-0 rounded-sm">
              <Percent className="w-3 h-3" /> GIẢM {discountVal}
            </span>
          )}
        </div>
      </div>

      {/* Product description specifics */}
      <div className="p-3 md:p-4 flex flex-col flex-grow bg-white">
        {/* Colors preview */}
        <div className="flex items-center gap-1.5 mb-2 overflow-x-auto no-scrollbar">
          {product.colors && product.colors.map((color, idx) => (
            <span
              key={`${color.name}-${idx}`}
              title={color.name}
              className="w-3.5 h-3.5 border border-gray-300 rounded-full inline-block shrink-0 ring-offset-1 select-none"
              style={{ backgroundColor: color.code }}
            />
          ))}
          {(!product.colors || product.colors.length === 0) && (
            <span className="text-[10px] text-gray-400">Một màu tiêu chuẩn</span>
          )}
        </div>

        {/* Subcategory */}
        <span className="text-[11px] font-medium text-gray-400 uppercase tracking-widest leading-none mb-1">
          {product.subcategory || "Thời trang LifeWear"}
        </span>

        {/* Title */}
        <h3 className="text-xs md:text-sm font-bold text-gray-900 line-clamp-2 leading-tight tracking-tight mb-2 flex-grow hover:text-[#E60012] transition-colors">
          {product.name}
        </h3>

        {/* Sizes banner list */}
        <div className="flex flex-wrap gap-1 mb-3">
          {product.sizes && product.sizes.map((sz, idx) => (
            <span
              key={`${sz}-${idx}`}
              className="px-1.5 py-0.5 border border-gray-100 text-[9px] font-semibold text-gray-500 bg-gray-50"
            >
              {sz}
            </span>
          ))}
        </div>

        {/* Price list */}
        <div className="flex items-baseline gap-2 mt-auto">
          <span className="text-sm md:text-base font-extrabold text-[#E60012]">
            {formatPrice(product.price)}
          </span>
          {product.originalPrice && product.originalPrice > product.price && (
            <span className="text-xs text-gray-400 line-through">
              {formatPrice(product.originalPrice)}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
