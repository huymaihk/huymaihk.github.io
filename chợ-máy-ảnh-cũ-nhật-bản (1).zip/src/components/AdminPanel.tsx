import React, { useState, useEffect } from 'react';
import { Product, Order } from '../types';
import { 
  KeyRound, ShieldCheck, Sparkles, Image as ImageIcon, Plus, 
  Trash2, Edit3, Calendar, Tag, Check, ArrowLeftRight, ShoppingCart, 
  Coins, Info, RefreshCw, Eye, EyeOff, X
} from 'lucide-react';
import { 
  addLiveProduct, updateLiveProduct, deleteLiveProduct, 
  getLiveOrders, updateOrderStatus 
} from '../firebase';

interface AdminPanelProps {
  products: Product[];
  onRefreshProducts: () => void;
  isAdminMode: boolean;
}

export default function AdminPanel({ products, onRefreshProducts, isAdminMode }: AdminPanelProps) {
  // Login credentials state
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loginError, setLoginError] = useState("");

  // Tabs inside panel
  const [activeTab, setActiveTab] = useState<"products" | "orders">("products");

  // Orders lists
  const [orders, setOrders] = useState<Order[]>([]);

  // Editing form state
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);

  // Form Fields
  const [prodName, setProdName] = useState("");
  const [prodPrice, setProdPrice] = useState<number>(15000000);
  const [prodOriginalPrice, setProdOriginalPrice] = useState<number | "">("");
  const [prodCategory, setProdCategory] = useState<"Máy Ảnh" | "Ống Kính" | "Phụ Kiện">("Máy Ảnh");
  const [prodSubcategory, setProdSubcategory] = useState("Mirrorless");
  const [prodDescription, setProdDescription] = useState("");
  const [prodImages, setProdImages] = useState<string[]>([]);
  const [newImageUrl, setNewImageUrl] = useState("");
  
  // Tag selections
  const [selectedSizes, setSelectedSizes] = useState<string[]>(["Nguyên Bản 99%", "95% (Có Xước Nhẹ)", "Fullbox Đầy Đủ Cores"]);
  const [selectedColors, setSelectedColors] = useState<{name: string, code: string}[]>([
    { name: "Đen Carbon", code: "#18181B" },
    { name: "Sắc Bạc Retro", code: "#D4D4D8" }
  ]);

  // Color Creator helper
  const [newColorName, setNewColorName] = useState("");
  const [newColorCode, setNewColorCode] = useState("#3B82F6");

  // SEO Fields
  const [prodSeoTitle, setProdSeoTitle] = useState("");
  const [prodSeoDescription, setProdSeoDescription] = useState("");
  const [prodSeoKeywords, setProdSeoKeywords] = useState("");

  // AI SEO Analyzer & Search metrics state variables
  const [seoScore, setSeoScore] = useState<number | null>(null);
  const [seoChecklist, setSeoChecklist] = useState<Array<{ item: string; passed: boolean; feedback: string }>>([]);
  const [seoSuggestions, setSeoSuggestions] = useState<string[]>([]);
  const [isAnalyzingSeo, setIsAnalyzingSeo] = useState(false);
  const [suggestedKeywords, setSuggestedKeywords] = useState<string[]>([]);
  const [isKeywordsLoading, setIsKeywordsLoading] = useState(false);

  // Submitting States
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isSeoLoading, setIsSeoLoading] = useState(false);
  const [isSubmitLoading, setIsSubmitLoading] = useState(false);
  const [formFeedback, setFormFeedback] = useState({ type: "", text: "" });

  const sizeOptions = ["XS", "S", "M", "L", "XL", "XXL", "110cm", "120cm", "130cm", "140cm", "150cm"];

  // Fetch orders upon login
  useEffect(() => {
    if (isLoggedIn) {
      loadOrders();
    }
  }, [isLoggedIn, activeTab]);

  const loadOrders = async () => {
    try {
      const liveOrders = await getLiveOrders();
      setOrders(liveOrders);
    } catch (e) {
      console.error(e);
    }
  };

  // Preset Auto-fill credential helper
  const handleAutofill = () => {
    setEmail("admin@uniqlo.com");
    setPassword("adminuniqlo123");
    setLoginError("");
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");

    if (email.trim() === "admin@uniqlo.com" && password === "adminuniqlo123") {
      setIsLoggedIn(true);
    } else {
      setLoginError("Sai email hoặc mật khẩu quản trị. Gợi ý: Hãy nhấn nút 'Tự động điền'!");
    }
  };

  // Convert File to compressed Base64 String
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    if (file.size > 2 * 1024 * 1024) {
      setFormFeedback({ type: "error", text: "Kích thước hình ảnh quá lớn (vui lòng chọn ảnh < 2MB để lưu vào Cloud Firestore)." });
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setProdImages([...prodImages, reader.result]);
        setFormFeedback({ type: "success", text: "Đọc ảnh thành công!" });
      }
    };
    reader.onerror = () => {
      setFormFeedback({ type: "error", text: "Không thể đọc file hình ảnh." });
    };
    reader.readAsDataURL(file);
  };

  // Add color block helper
  const handleAddColor = () => {
    if (!newColorName.trim()) return;
    // Check duplication
    if (selectedColors.some(c => c.name.toLowerCase() === newColorName.trim().toLowerCase())) {
      setNewColorName("");
      return;
    }
    setSelectedColors([...selectedColors, { name: newColorName.trim(), code: newColorCode }]);
    setNewColorName("");
  };

  const handleRemoveColor = (index: number) => {
    setSelectedColors(selectedColors.filter((_, i) => i !== index));
  };

  // Toggle size checkbox helper
  const handleToggleSize = (size: string) => {
    if (selectedSizes.includes(size)) {
      setSelectedSizes(selectedSizes.filter(s => s !== size));
    } else {
      setSelectedSizes([...selectedSizes, size]);
    }
  };

  // Gemini AI Copywriter
  const handleGenerateDescription = async () => {
    if (!prodName.trim()) {
      setFormFeedback({ type: "error", text: "Vui lòng nhập Tên sản phẩm trước khi yêu cầu AI viết mô tả!" });
      return;
    }

    setIsAiLoading(true);
    setFormFeedback({ type: "info", text: "Gemini AI đang suy luận mô tả thời trang..." });

    try {
      const response = await fetch("/api/gemini/generate-description", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: prodName.trim(),
          category: prodCategory,
          subcategory: prodSubcategory,
          bulletPoints: prodDescription
        })
      });

      const data = await response.json();
      if (response.ok && data.description) {
        setProdDescription(data.description);
        setFormFeedback({ type: "success", text: "Đã tạo mô tả phong cách Uniqlo thành công nhờ Gemini AI!" });
      } else {
        throw new Error(data.error || "Failed to generate content");
      }
    } catch (err: any) {
      setFormFeedback({ type: "error", text: err.message || "Không thể kết nối đến AI. Hãy chắc chắn khoá GEMINI_API_KEY đã hợp lệ." });
    } finally {
      setIsAiLoading(false);
    }
  };

  // Gemini AI SEO tags creator
  const handleGenerateSeo = async () => {
    if (!prodName.trim()) {
      setFormFeedback({ type: "error", text: "Vui lòng nhập Tên sản phẩm trước khi tạo SEO!" });
      return;
    }

    setIsSeoLoading(true);
    setFormFeedback({ type: "info", text: "Gemini AI đang lập chỉ mục SEO..." });

    try {
      const response = await fetch("/api/gemini/generate-seo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: prodName.trim(),
          category: prodCategory,
          subcategory: prodSubcategory,
          description: prodDescription
        })
      });

      const data = await response.json();
      if (response.ok && data.seoTitle) {
        setProdSeoTitle(data.seoTitle);
        setProdSeoDescription(data.seoDescription);
        setProdSeoKeywords(data.seoKeywords);
        setFormFeedback({ type: "success", text: "AI đã điền xong tiêu đề, thẻ mô tả và từ khoá SEO tối ưu!" });
      } else {
        throw new Error(data.error || "Failed to generate SEO");
      }
    } catch (err: any) {
      setFormFeedback({ type: "error", text: err.message || "Không thể kết nối đến AI." });
    } finally {
      setIsSeoLoading(false);
    }
  };

  // NEW METHOD: Analyze SEO parameters
  const handleAnalyzeSeo = async () => {
    setIsAnalyzingSeo(true);
    setFormFeedback({ type: "info", text: "Chuyên gia AI đang phân tích toàn diện điểm SEO..." });

    try {
      const response = await fetch("/api/gemini/analyze-seo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: prodName.trim(),
          description: prodDescription.trim(),
          seoTitle: prodSeoTitle.trim(),
          seoDescription: prodSeoDescription.trim(),
          seoKeywords: prodSeoKeywords.trim(),
        }),
      });

      const data = await response.json();
      if (response.ok) {
        setSeoScore(data.score);
        setSeoChecklist(data.checklist || []);
        setSeoSuggestions(data.suggestions || []);
        setFormFeedback({ type: "success", text: `Đã hoàn tất phân tích SEO! Điểm chất lượng: ${data.score}/100.` });
      } else {
        throw new Error(data.error || "Failed to analyze SEO");
      }
    } catch (err: any) {
      setFormFeedback({ type: "error", text: err.message || "Lỗi khi phân tích SEO." });
    } finally {
      setIsAnalyzingSeo(false);
    }
  };

  // NEW METHOD: Fetch trending keywords of product
  const handleGetKeywords = async () => {
    if (!prodName.trim()) {
      setFormFeedback({ type: "error", text: "Vui lòng nhập Tên sản phẩm để AI nghiên cứu từ khóa hot." });
      return;
    }

    setIsKeywordsLoading(true);
    setFormFeedback({ type: "info", text: "AI đang rà soát dữ liệu tìm kiếm Google thị trường Việt Nam..." });

    try {
      const response = await fetch("/api/gemini/suggest-keywords", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: prodName.trim(),
          category: prodCategory,
          subcategory: prodSubcategory.trim(),
        }),
      });

      const data = await response.json();
      if (response.ok && data.keywords) {
        setSuggestedKeywords(data.keywords);
        setFormFeedback({ type: "success", text: "Đã trích xuất danh sách từ khóa có lượt tìm kiếm hàng đầu!" });
      } else {
        throw new Error(data.error || "Failed to suggest keywords");
      }
    } catch (err: any) {
      setFormFeedback({ type: "error", text: err.message || "Lỗi gợi ý từ khóa." });
    } finally {
      setIsKeywordsLoading(false);
    }
  };

  // Helper: append a chip into the keywords text input
  const handleAddKeywordChip = (kw: string) => {
    const trimmedKw = kw.trim();
    if (!trimmedKw) return;

    // Split existing keywords to check duplication
    const currentList = prodSeoKeywords
      .split(",")
      .map((k) => k.trim())
      .filter((k) => k.length > 0);

    if (currentList.some((k) => k.toLowerCase() === trimmedKw.toLowerCase())) {
      return; // Already added
    }

    const newList = [...currentList, trimmedKw];
    setProdSeoKeywords(newList.join(", "));
  };

  // Trigger form opening for adding
  const handleOpenAddForm = () => {
    setEditingProduct(null);
    setProdName("");
    setProdPrice(15000000);
    setProdOriginalPrice("");
    setProdCategory("Máy Ảnh");
    setProdSubcategory("Mirrorless");
    setProdDescription("");
    setProdImages([]);
    setSelectedSizes(["Nguyên Bản 99%", "95% (Có Xước Nhẹ)"]);
    setSelectedColors([
      { name: "Đen Carbon", code: "#18181B" },
      { name: "Sắc Bạc Retro", code: "#D4D4D8" }
    ]);
    setProdSeoTitle("");
    setProdSeoDescription("");
    setProdSeoKeywords("");

    // Clear analytical states
    setSeoScore(null);
    setSeoChecklist([]);
    setSeoSuggestions([]);
    setSuggestedKeywords([]);

    setFormFeedback({ type: "", text: "" });
    setIsFormOpen(true);
  };

  // Open Form for edit mode
  const handleOpenEditForm = (prod: Product) => {
    setEditingProduct(prod);
    setProdName(prod.name);
    setProdPrice(prod.price);
    setProdOriginalPrice(prod.originalPrice || "");
    setProdCategory(prod.category);
    setProdSubcategory(prod.subcategory || "Áo thun");
    setProdDescription(prod.description);
    setProdImages(prod.images || []);
    setSelectedSizes(prod.sizes || []);
    setSelectedColors(prod.colors || []);
    setProdSeoTitle(prod.seoTitle || "");
    setProdSeoDescription(prod.seoDescription || "");
    setProdSeoKeywords(prod.seoKeywords || "");

    // Clear analytical states
    setSeoScore(null);
    setSeoChecklist([]);
    setSeoSuggestions([]);
    setSuggestedKeywords([]);

    setFormFeedback({ type: "", text: "" });
    setIsFormOpen(true);
  };

  // Delete product action
  const handleDeleteProduct = async (id: string) => {
    if (confirm("Bạn có tin chắc muốn xóa vĩnh viễn sản phẩm này khỏi hệ thống không?")) {
      try {
        await deleteLiveProduct(id);
        onRefreshProducts();
      } catch (e: any) {
        alert("Lỗi khi xóa: " + e.message);
      }
    }
  };

  // Change order status action
  const handleChangeOrderStatus = async (orderId: string, status: Order["status"]) => {
    try {
      await updateOrderStatus(orderId, status);
      loadOrders();
    } catch (e: any) {
      alert("Lỗi khi cập nhật trạng thái: " + e.message);
    }
  };

  // Submit main ADD or EDIT form
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormFeedback({ type: "", text: "" });

    if (!prodName.trim()) {
      setFormFeedback({ type: "error", text: "Vui lòng nhập tên sản phẩm." });
      return;
    }

    if (prodImages.length === 0) {
      setFormFeedback({ type: "error", text: "Vui lòng thêm ít nhất 1 hình ảnh sản phẩm (điền link hoặc chọn file đính kèm)." });
      return;
    }

    setIsSubmitLoading(true);

    try {
      const payload: any = {
        name: prodName.trim(),
        price: Number(prodPrice),
        category: prodCategory,
        subcategory: prodSubcategory.trim(),
        description: prodDescription.trim(),
        images: prodImages,
        sizes: selectedSizes,
        colors: selectedColors,
        seoTitle: prodSeoTitle.trim() || undefined,
        seoDescription: prodSeoDescription.trim() || undefined,
        seoKeywords: prodSeoKeywords.trim() || undefined,
      };

      if (prodOriginalPrice !== "") {
        payload.originalPrice = Number(prodOriginalPrice);
      }

      if (editingProduct) {
        // Edit mode
        const toSave = {
          ...editingProduct,
          ...payload
        };
        await updateLiveProduct(toSave);
        setFormFeedback({ type: "success", text: "Đã cập nhật sản phẩm thành công trên hệ thống!" });
      } else {
        // Add Mode
        await addLiveProduct(payload);
        setFormFeedback({ type: "success", text: "Sản phẩm mới đã được đăng tải thành công tuyệt đẹp!" });
      }

      onRefreshProducts();
      setTimeout(() => {
        setIsFormOpen(false);
      }, 1500);

    } catch (err: any) {
      setFormFeedback({ type: "error", text: "Lỗi lưu sản phẩm: " + err.message });
    } finally {
      setIsSubmitLoading(false);
    }
  };

  const formatPrice = (value: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value);
  };

  // Calculates stats metrics
  const getStats = () => {
    const totalProd = products.length;
    const totalOrders = orders.length;
    const calculatedRevenue = orders
      .filter(o => o.status !== "Đã hủy")
      .reduce((sum, o) => sum + o.totalAmount, 0);

    return { totalProd, totalOrders, calculatedRevenue };
  };

  const stats = getStats();

  // If not logged in, show Password-Gate box
  if (!isLoggedIn) {
    return (
      <div className="max-w-md mx-auto my-12 p-6 md:p-8 bg-white border border-gray-200">
        <div id="admin-login-lock-head" className="text-center mb-6">
          <div className="mx-auto w-12 h-12 bg-red-100 flex items-center justify-center rounded-full text-[#E60012] mb-3">
            <KeyRound className="w-6 h-6" />
          </div>
          <h2 className="text-base font-black text-gray-900 tracking-wider">UNIQLO OWNER LOG-IN</h2>
          <p className="text-xs text-gray-400 mt-1">Đăng nhập tài khoản quản trị để đăng sản phẩm nhanh chóng không cần viết code</p>
        </div>

        <form onSubmit={handleLoginSubmit} id="form-admin-login" className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Email Đại lý / Admin</label>
            <input
              type="email"
              value={email}
              aria-label="Email Address"
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@uniqlo.com"
              required
              className="w-full text-xs px-3 py-2 border border-gray-300 focus:outline-none focus:border-[#E60012]"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Mật khẩu</label>
            <input
              type="password"
              value={password}
              aria-label="Password"
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              className="w-full text-xs px-3 py-2 border border-gray-300 focus:outline-none focus:border-[#E60012]"
            />
          </div>

          {loginError && (
            <p className="text-xs text-red-600 bg-red-50 p-2 border-l-4 border-red-500 font-semibold">
              {loginError}
            </p>
          )}

          <div className="pt-2 flex flex-col gap-2">
            <button
              id="btn-admin-login-submit"
              type="submit"
              className="w-full bg-[#E60012] hover:bg-red-700 text-white font-black text-xs py-3 uppercase tracking-widest cursor-pointer"
            >
              Đăng Nhập Quản Trị
            </button>
            
            <button
              id="btn-autofill-login"
              type="button"
              onClick={handleAutofill}
              className="w-full bg-gray-50 hover:bg-gray-100 text-gray-700 font-bold border border-gray-300 text-xs py-2 uppercase tracking-wide"
            >
              🚀 Tự Động Điền Tài Khoản Demo
            </button>
          </div>
        </form>

        <div className="mt-6 border-t border-gray-200 pt-4 text-center">
          <p className="text-[10px] text-gray-400 leading-normal font-sans">
            Tài khoản thử nghiệm mặc định:<br />
            Email: <strong className="text-gray-600">admin@uniqlo.com</strong><br />
            Mật khẩu: <strong className="text-gray-600">adminuniqlo123</strong>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in" id="panel-admin-authenticated">
      
      {/* Top dashboard header info */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-lg md:text-2xl font-black text-gray-900 flex items-center gap-2">
            <ShieldCheck className="w-7 h-7 text-[#E60012]" /> BẢNG ĐIỀU KHIỂN CHỦ SỞ HỮU GIAN HÀNG
          </h1>
          <p className="text-xs text-gray-500">
            Chào mừng admin! Hệ thống cung cấp khả năng thêm sản phẩm trực quan, tự phát mô tả và tạo SEO tuyệt đỉnh bằng AI.
          </p>
        </div>

        <div className="flex gap-2">
          <button
            id="tab-btn-products"
            onClick={() => setActiveTab("products")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider relative transition-all cursor-pointer ${
              activeTab === "products"
                ? "bg-gray-900 text-white"
                : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
            }`}
          >
            Quản lý sản phẩm
          </button>
          <button
            id="tab-btn-orders"
            onClick={() => setActiveTab("orders")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider relative transition-all cursor-pointer ${
              activeTab === "orders"
                ? "bg-gray-900 text-white"
                : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
            }`}
          >
            Đơn hàng khách ({orders.length})
          </button>
        </div>
      </div>

      {/* Admin stats metrics dashboard widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <div className="bg-white border border-gray-200 p-4 shrink-0 flex items-center gap-4 shadow-xs">
          <div className="p-3 bg-red-50 text-[#E60012] rounded-full">
            <Tag className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-gray-400 uppercase">Danh mục sản phẩm</p>
            <p className="text-lg md:text-2xl font-black text-gray-900">{stats.totalProd} Sản Phẩm</p>
          </div>
        </div>

        <div className="bg-white border border-gray-200 p-4 shrink-0 flex items-center gap-4 shadow-xs">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-full">
            <ShoppingCart className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-gray-400 uppercase">Khách đã đặt mua</p>
            <p className="text-lg md:text-2xl font-black text-gray-900">{stats.totalOrders} Đơn Hàng</p>
          </div>
        </div>

        <div className="bg-white border border-gray-200 p-4 shrink-0 flex items-center gap-4 shadow-xs">
          <div className="p-3 bg-green-50 text-green-600 rounded-full">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-gray-400 uppercase">Doanh số dự kiến (COD)</p>
            <p className="text-lg md:text-2xl font-black text-green-600">{formatPrice(stats.calculatedRevenue)}</p>
          </div>
        </div>
      </div>

      {/* Dynamic Tabs Content: products tab */}
      {activeTab === "products" && (
        <div id="admin-products-tab" className="bg-white border border-gray-200 p-4 md:p-6 shadow-xs">
          
          <div className="flex justify-between items-center pb-4 mb-6 border-b border-gray-200">
            <h2 className="text-sm md:text-base font-extrabold text-gray-900 uppercase tracking-widest">Danh sách thiết bị trưng bày</h2>
            <button
              id="btn-add-product-open-modal"
              onClick={handleOpenAddForm}
              className="bg-[#E60012] hover:bg-red-700 text-white font-extrabold text-xs px-4 py-2.5 flex items-center gap-1.5 cursor-pointer uppercase tracking-wider"
            >
              <Plus className="w-4 h-4" /> Đăng sản phẩm mới
            </button>
          </div>

          {/* ADD / EDIT Product Form Panel */}
          {isFormOpen && (
            <div className="mb-10 bg-gray-50/70 border border-gray-300 p-4 sm:p-6 rounded-xs relative">
              <div className="absolute top-4 right-4">
                <button
                  id="btn-close-form"
                  onClick={() => setIsFormOpen(false)}
                  className="text-gray-400 hover:text-black font-extrabold"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <h2 className="text-sm md:text-base font-black text-gray-900 uppercase tracking-widest mb-6">
                {editingProduct ? `✏️ Cập Nhật Chi Tiết: ${editingProduct.name}` : "✨ Đăng Sản Phẩm Mới (Tải cực nhanh)"}
              </h2>

              <form onSubmit={handleFormSubmit} className="space-y-6">
                
                {/* Visual Feedback Alerts */}
                {formFeedback.text && (
                  <div className={`p-3 text-xs leading-relaxed border-l-4 font-semibold ${
                    formFeedback.type === "error" ? "bg-red-50 text-red-600 border-red-500" :
                    formFeedback.type === "success" ? "bg-green-50 text-green-700 border-green-500" :
                    "bg-blue-50 text-blue-700 border-blue-500"
                  }`}>
                    {formFeedback.text}
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  
                  {/* Left block information */}
                  <div className="md:col-span-2 space-y-4">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Tên Sản Phẩm *</label>
                      <input
                        type="text"
                        value={prodName}
                        onChange={(e) => setProdName(e.target.value)}
                        placeholder="Ví dụ: Sony Alpha 7 Mark III Full-Frame Mirrorless"
                        required
                        className="w-full text-xs px-3 py-2.5 border border-gray-300 bg-white shadow-2xs focus:border-[#E60012] focus:outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Danh Mục Thiết Bị *</label>
                        <select
                          value={prodCategory}
                          onChange={(e) => setProdCategory(e.target.value as any)}
                          className="w-full text-xs px-3 py-2.5 border border-gray-300 bg-white focus:border-[#E60012] focus:outline-none"
                        >
                          <option value="Máy Ảnh">Máy Ảnh Cũ</option>
                          <option value="Ống Kính">Ống Kính (Lenses)</option>
                          <option value="Phụ Kiện">Phụ Kiện Nhiếp Ảnh</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Phân Loại Kỹ Thuật *</label>
                        <input
                          type="text"
                          value={prodSubcategory}
                          onChange={(e) => setProdSubcategory(e.target.value)}
                          placeholder="Ví dụ: Mirrorless, DSLR, Prime Lens, Zoom Lens"
                          required
                          className="w-full text-xs px-3 py-2.5 border border-gray-300 bg-white focus:border-[#E60012] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Giá bán hiện tại (₫) *</label>
                        <input
                          type="number"
                          value={prodPrice}
                          onChange={(e) => setProdPrice(Number(e.target.value))}
                          placeholder="Gõ số, ví dụ 399000"
                          required
                          className="w-full text-xs px-3 py-2.5 border border-gray-300 bg-white focus:border-[#E60012] focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Giá so sánh gốc (₫) - Hiển thị giảm giá</label>
                        <input
                          type="number"
                          value={prodOriginalPrice}
                          onChange={(e) => setProdOriginalPrice(e.target.value === "" ? "" : Number(e.target.value))}
                          placeholder="Ví dụ 499000 (Để trống nếu bán giá thường)"
                          className="w-full text-xs px-3 py-2.5 border border-gray-300 bg-white focus:border-[#E60012] focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* AI Copywriter box */}
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="block text-[10px] font-bold text-gray-500 uppercase">Mô tả sản phẩm và Công nghệ dệt</label>
                        <button
                          type="button"
                          onClick={handleGenerateDescription}
                          disabled={isAiLoading}
                          className="text-xs bg-[#E60012]/10 text-[#E60012] px-2.5 py-1 font-bold border border-[#E60012]/30 hover:bg-[#E60012] hover:text-white transition-all flex items-center gap-1 cursor-pointer disabled:bg-gray-200 disabled:text-gray-400"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          {isAiLoading ? "Đang viết..." : "Tự động viết nội dung Uniqlo bằng AI"}
                        </button>
                      </div>
                      <textarea
                        value={prodDescription}
                        onChange={(e) => setProdDescription(e.target.value)}
                        rows={10}
                        placeholder="Hãy gõ vài từ thô (vd: áo giữ nhiệt mỏng nhẹ ôm dáng rất ấm). Click nút vàng AI phía trên để nâng cấp thành mô tả chuẩn Uniqlo Vietnam đầy hấp dẫn!"
                        className="w-full text-xs px-3 py-2.5 border border-gray-300 bg-white font-mono leading-relaxed focus:border-[#E60012] focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Right blocks: image selectors, colors, sizes */}
                  <div className="space-y-4">
                    
                    {/* Image uploads */}
                    <div className="bg-white border p-4 space-y-3">
                      <h3 className="text-xs font-bold text-gray-900 border-b pb-1.5 flex items-center gap-1.5 uppercase">
                        <ImageIcon className="w-4 h-4 text-red-500" /> Thêm hình ảnh sản phẩm *
                      </h3>

                      <div className="space-y-2">
                        <label className="block text-[10px] font-bold text-gray-400 uppercase">Phương án 1: Tải file ảnh từ máy</label>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                          className="w-full text-xs text-gray-500 file:mr-2 file:py-1 file:px-2 file:border-0 file:text-[10px] file:font-semibold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200"
                        />
                      </div>

                      <div className="space-y-2 pt-2 border-t border-dashed">
                        <label className="block text-[10px] font-bold text-gray-400 uppercase">Phương án 2: Dán đường dẫn URL ảnh</label>
                        <div className="flex gap-1.5">
                          <input
                            type="text"
                            value={newImageUrl}
                            onChange={(e) => setNewImageUrl(e.target.value)}
                            placeholder="https://images.unsplash.com/photo-..."
                            className="w-full text-xs px-2 py-1.5 border"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              if (newImageUrl.trim()) {
                                setProdImages([...prodImages, newImageUrl.trim()]);
                                setNewImageUrl("");
                              }
                            }}
                            className="bg-gray-900 text-white font-bold text-xs px-3"
                          >
                            Lưu
                          </button>
                        </div>
                      </div>

                      {/* Display image queue */}
                      {prodImages.length > 0 && (
                        <div className="flex flex-wrap gap-2 pt-2">
                          {prodImages.map((img, i) => (
                            <div key={i} className="relative w-12 h-15 border rounded-xs group shrink-0">
                              <img src={img} alt="Thumb" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                              <button
                                type="button"
                                onClick={() => setProdImages(prodImages.filter((_, idx) => idx !== i))}
                                className="absolute -top-1 -right-1 bg-red-600 text-white p-0.5 rounded-full opacity-60 hover:opacity-100"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Sizing picks */}
                    <div className="bg-white border p-4 space-y-2">
                      <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wider">Kích cỡ sẵn có</h3>
                      <div className="flex flex-wrap gap-1.5">
                        {sizeOptions.map((sz) => {
                          const hasSz = selectedSizes.includes(sz);
                          return (
                            <button
                              key={sz}
                              type="button"
                              onClick={() => handleToggleSize(sz)}
                              className={`px-2.5 py-1 text-[10px] font-extrabold border transition-colors ${
                                hasSz ? "bg-gray-900 text-white border-black" : "bg-white text-gray-500 border-gray-200"
                              }`}
                            >
                              {sz}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Color picks */}
                    <div className="bg-white border p-4 space-y-2">
                      <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wider">Màu sắc sẵn có</h3>
                      <div className="flex flex-wrap gap-1">
                        {selectedColors.map((color, i) => (
                          <span
                            key={i}
                            className="inline-flex items-center gap-1 px-1.5 py-0.5 border text-[10px] text-gray-700 font-medium"
                          >
                            <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: color.code }} />
                            {color.name}
                            <button type="button" onClick={() => handleRemoveColor(i)} className="text-red-500 font-bold ml-1 hover:text-black">×</button>
                          </span>
                        ))}
                      </div>

                      {/* Incremental Color Adder */}
                      <div className="pt-2 border-t border-dashed flex items-center gap-1.5">
                        <input
                          type="text"
                          value={newColorName}
                          onChange={(e) => setNewColorName(e.target.value)}
                          placeholder="Tên màu (ví dụ Ghi nhạt)"
                          className="text-[11px] px-2 py-1 border flex-grow max-w-[120px]"
                        />
                        <input
                          type="color"
                          value={newColorCode}
                          aria-label="Color Picker"
                          onChange={(e) => setNewColorCode(e.target.value)}
                          className="w-6 h-6 border cursor-pointer shrink-0"
                        />
                        <button
                          type="button"
                          onClick={handleAddColor}
                          className="bg-gray-100 hover:bg-gray-200 text-gray-700 p-1.5 border"
                        >
                          Thêm
                        </button>
                      </div>
                    </div>

                  </div>
                </div>

                {/* AI-powered SEO Optimizations & Diagnostic block */}
                <div className="bg-red-50/20 border border-red-200 p-4 sm:p-5">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4 border-b border-red-100 pb-3">
                    <div>
                      <h3 className="text-xs font-black text-gray-900 uppercase flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-[#E60012]" /> CÔNG CỤ TỐI ƯU HÓA SEO ĐẦU RA GOOGLE (AI-POWERED)
                      </h3>
                      <p className="text-[10px] text-gray-500 font-medium">Bố trí thẻ Meta, phân tích từ khóa Việt Nam thế hệ mới giúp sản phẩm phát triển lên top 1 tìm kiếm.</p>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={handleGenerateSeo}
                        disabled={isSeoLoading}
                        className="text-xs bg-[#E60012] hover:bg-red-700 text-white font-extrabold px-3 py-1.5 flex items-center gap-1 cursor-pointer disabled:bg-gray-300 transition-all shadow-2xs"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        {isSeoLoading ? "Đang viết..." : "Tự Động Tạo Thẻ Thô Bằng AI"}
                      </button>

                      <button
                        type="button"
                        onClick={handleAnalyzeSeo}
                        disabled={isAnalyzingSeo || !prodName}
                        className="text-xs bg-gray-900 hover:bg-black text-white font-extrabold px-3 py-1.5 flex items-center gap-1 cursor-pointer disabled:bg-gray-300 transition-all shadow-2xs"
                      >
                        <RefreshCw className="w-3.5 h-3.5 animate-spin-slow" />
                        {isAnalyzingSeo ? "Mô phỏng rank..." : "Kiểm tra Điểm Số SEO"}
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="block text-[10px] font-bold text-gray-700 uppercase">Tiêu đề SEO của sản phẩm (seoTitle)</label>
                        <span className="text-[9px] text-gray-400 font-mono">Ý tưởng: 50 - 60 ký tự ({prodSeoTitle.length} ký tự)</span>
                      </div>
                      <input
                        type="text"
                        value={prodSeoTitle}
                        onChange={(e) => setProdSeoTitle(e.target.value)}
                        placeholder="Ví dụ: Áo Phao Lông Vũ Siêu Nhẹ Ultra Light Down Uniqlo"
                        className="w-full text-xs px-2.5 py-2 border border-gray-300 bg-white focus:outline-none focus:border-[#E60012] shadow-sm font-medium"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="block text-[10px] font-bold text-gray-700 uppercase">Mô tả SEO tóm lược (seoDescription)</label>
                        <span className="text-[9px] text-gray-400 font-mono">Tối đa 160 ký tự ({prodSeoDescription.length} ký tự)</span>
                      </div>
                      <textarea
                        value={prodSeoDescription}
                        onChange={(e) => setProdSeoDescription(e.target.value)}
                        rows={1}
                        placeholder="Mô tả tóm tắt hấp dẫn lôi kéo người dùng Google nhấp chuột mua hàng."
                        className="w-full text-xs px-2.5 py-2 border border-gray-300 bg-white focus:outline-none focus:border-[#E60012] shadow-sm font-medium"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="block text-[10px] font-bold text-gray-700 uppercase">Thẻ Từ khóa tìm kiếm (seoKeywords)</label>
                        <span className="text-[9px] text-gray-400 font-mono">Cách nhau bằng dấu phẩy</span>
                      </div>
                      <input
                        type="text"
                        value={prodSeoKeywords}
                        onChange={(e) => setProdSeoKeywords(e.target.value)}
                        placeholder="máy ảnh cũ, canon 5d3 cũ hanoi, lens sony lướt chính hãng"
                        className="w-full text-xs px-2.5 py-2 border border-gray-300 bg-white focus:outline-none focus:border-[#E60012] shadow-sm font-medium"
                      />
                    </div>
                  </div>

                  {/* Trending Keywords panel addition */}
                  <div className="mt-4 pt-3 border-t border-dashed border-red-100">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                      <p className="text-[10px] font-extrabold text-gray-600 uppercase flex items-center gap-1">
                        <Tag className="w-3.5 h-3.5 text-red-500" /> Đề xuất từ khoá SEO Hot Trend từ Google Việt Nam
                      </p>
                      <button
                        type="button"
                        onClick={handleGetKeywords}
                        disabled={isKeywordsLoading || !prodName}
                        className="text-[10px] bg-red-100 text-[#E60012] font-extrabold px-2 py-1 text-center hover:bg-[#E60012] hover:text-white transition-all disabled:bg-gray-200 disabled:text-gray-400 cursor-pointer"
                      >
                        {isKeywordsLoading ? "Đang trích xuất..." : "🔎 Gợi ý Từ Khóa Định Hướng Tìm Kiếm"}
                      </button>
                    </div>

                    {suggestedKeywords.length > 0 ? (
                      <div className="bg-white border rounded-xs p-2.5 space-y-1.5">
                        <span className="text-[9px] text-gray-400 block italic">Mẹo: Click vào từ khoá bên dưới để thêm ngay vào Thẻ Từ Khoá của sản phẩm:</span>
                        <div className="flex flex-wrap gap-1.5">
                          {suggestedKeywords.map((kw, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => handleAddKeywordChip(kw)}
                              className="text-[10px] bg-gray-50 border hover:bg-red-50 hover:border-red-300 hover:text-[#E60012] px-2 py-0.5 rounded-full transition-colors cursor-pointer font-medium"
                            >
                              + {kw}
                            </button>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <p className="text-[9px] text-gray-400">Chưa tải từ khoá gợi ý. Bấm nút phía trên để AI gợi ý các truy vấn được người dùng Việt Nam gõ nhiều nhất.</p>
                    )}
                  </div>

                  {/* AI SEO Diagnostics result card */}
                  {seoScore !== null && (
                    <div className="mt-5 bg-white border border-gray-300 p-4 sm:p-5 shadow-xs animate-fade-in space-y-4">
                      
                      <div className="flex items-center justify-between border-b pb-2">
                        <div className="flex items-center gap-2">
                          <div className={`w-12 h-12 rounded-full border-4 flex items-center justify-center font-black text-xs ${
                            seoScore >= 80 ? "border-green-500 text-green-600 bg-green-50" :
                            seoScore >= 50 ? "border-amber-500 text-amber-600 bg-amber-50" :
                            "border-red-500 text-red-600 bg-red-50"
                          }`}>
                            {seoScore}/100
                          </div>
                          <div>
                            <h4 className="text-xs font-black text-gray-900 uppercase">CHẨN ĐOÁN CHẤT LƯỢNG SEO TRANG WEB</h4>
                            <p className="text-[10px] text-gray-400">Được lập báo cáo tự động bởi mô hình Gemini 3.5 Flash</p>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className={`text-[10px] inline-block font-extrabold px-2 py-0.5 uppercase ${
                            seoScore >= 80 ? "bg-green-100 text-green-700" :
                            seoScore >= 50 ? "bg-amber-100 text-amber-700" :
                            "bg-red-100 text-red-700"
                          }`}>
                            {seoScore >= 80 ? "Sẵn sàng lên top" : seoScore >= 50 ? "Cần tinh chỉnh nhẹ" : "Chưa tối ưu"}
                          </span>
                        </div>
                      </div>

                      {/* Checklist criteria */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                        {seoChecklist.map((item, idx) => (
                          <div key={idx} className="flex gap-2 p-2 border border-gray-100 bg-gray-50/50">
                            <span className="shrink-0 mt-0.5">
                              {item.passed ? (
                                <span className="text-green-600 font-bold bg-green-100 px-1 py-0.5 rounded-full text-[9px]">✓ Đạt</span>
                              ) : (
                                <span className="text-red-600 font-bold bg-red-100 px-1 py-0.5 rounded-full text-[9px]">✗ Sửa</span>
                              )}
                            </span>
                            <div>
                              <p className="font-extrabold text-[#18181b]">{item.item}</p>
                              <p className="text-[10px] text-gray-500 mt-0.5 leading-normal">{item.feedback}</p>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Expert suggestions action items */}
                      {seoSuggestions.length > 0 && (
                        <div className="bg-amber-50/70 border border-amber-200 p-3">
                          <p className="text-[10px] font-black text-amber-900 uppercase mb-1.5 flex items-center gap-1.5">
                            <Info className="w-3.5 h-3.5 text-amber-600" /> BẢN KẾ HOẠCH HÀNH ĐỘNG TẤN CÔNG TOP 1 TÌM KIẾM GOOGLE:
                          </p>
                          <ul className="list-disc pl-4 text-[10.5px] text-amber-800 space-y-1.5 leading-normal">
                            {seoSuggestions.map((sug, idx) => (
                              <li key={idx} className="font-medium">{sug}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                    </div>
                  )}

                </div>

                {/* Submitting buttons footer */}
                <div className="flex gap-3 justify-end pt-4 border-t border-gray-200">
                  <button
                    type="button"
                    onClick={() => setIsFormOpen(false)}
                    className="px-5 py-2.5 border border-gray-300 bg-white hover:bg-gray-100 text-xs font-bold uppercase tracking-wider cursor-pointer"
                  >
                    Bỏ qua
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmitLoading}
                    className="px-8 py-2.5 bg-[#E60012] hover:bg-red-700 text-white text-xs font-black uppercase tracking-widest cursor-pointer disabled:bg-gray-300"
                  >
                    {isSubmitLoading ? "Đang đăng dữ liệu..." : editingProduct ? "Lưu Cập Nhật" : "Xác Nhận Đăng Bán Sản Phẩm"}
                  </button>
                </div>

              </form>
            </div>
          )}

          {/* Catalog items display list within Admin */}
          <div className="overflow-x-auto border border-gray-200">
            <table className="min-w-full divide-y divide-gray-200 text-xs text-left" id="admin-products-table">
              <thead className="bg-gray-50 font-bold uppercase tracking-wide text-gray-600">
                <tr>
                  <th scope="col" className="px-4 py-3">Ảnh đại diện</th>
                  <th scope="col" className="px-4 py-3">Tên sản phẩm</th>
                  <th scope="col" className="px-4 py-3">Thể loại</th>
                  <th scope="col" className="px-4 py-3">Phân loại phụ</th>
                  <th scope="col" className="px-4 py-3">Đơn giá</th>
                  <th scope="col" className="px-4 py-3 text-right">Thao tác</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-100">
                {products.map((prod) => (
                  <tr key={prod.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 whitespace-nowrap">
                      <img src={prod.images[0]} alt={prod.name} referrerPolicy="no-referrer" className="w-10 h-13 object-cover border" />
                    </td>
                    <td className="px-4 py-3 font-semibold text-gray-900 max-w-xs truncate">
                      {prod.name}
                    </td>
                    <td className="px-4 py-3 font-bold text-gray-400">
                      {prod.category}
                    </td>
                    <td className="px-4 py-3">
                      {prod.subcategory || "Áo thun"}
                    </td>
                    <td className="px-4 py-3 font-bold text-red-600">
                      {formatPrice(prod.price)}
                    </td>
                    <td className="px-4 py-3 text-right space-x-1.5 whitespace-nowrap">
                      <button
                        onClick={() => handleOpenEditForm(prod)}
                        className="text-blue-600 hover:bg-blue-50 p-1.5 border border-blue-200 rounded-sm inline-flex items-center gap-1 font-bold"
                        title="Sửa"
                      >
                        <Edit3 className="w-3.5 h-3.5" /> Sửa
                      </button>
                      <button
                        onClick={() => handleDeleteProduct(prod.id)}
                        className="text-red-600 hover:bg-red-50 p-1.5 border border-red-200 rounded-sm inline-flex items-center gap-1 font-bold"
                        title="Xóa"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Xóa
                      </button>
                    </td>
                  </tr>
                ))}
                {products.length === 0 && (
                  <tr>
                    <td colSpan={6} className="text-center py-8 text-gray-400">Hệ thống sản phẩm trưng bày rỗng. Hãy thêm sản phẩm nhé!</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

        </div>
      )}

      {/* Dynamic Tabs Content: orders approval dashboard */}
      {activeTab === "orders" && (
        <div id="admin-orders-tab" className="bg-white border border-gray-200 p-4 md:p-6 shadow-xs">
          <div className="flex justify-between items-center pb-4 mb-6 border-b border-gray-200">
            <h2 className="text-sm md:text-base font-extrabold text-gray-900 uppercase tracking-widest flex items-center gap-2">
              Danh sách đơn đặt hàng từ khách mua
              <button onClick={loadOrders} className="p-1 hover:text-[#E60012]" title="Tải lại">
                <RefreshCw className="w-4 h-4" />
              </button>
            </h2>
          </div>

          <div className="space-y-6">
            {orders.map((ord) => (
              <div key={ord.id} className="border border-gray-200 bg-white p-4 space-y-4 shadow-2xs">
                
                {/* Header detail info of an order */}
                <div className="flex flex-col sm:flex-row justify-between border-b pb-2.5 gap-2 text-xs">
                  <div>
                    <p className="font-extrabold text-gray-900 text-sm">ĐƠN HÀNG #{ord.id.split('_').pop()}</p>
                    <p className="text-gray-400 flex items-center gap-1.5 mt-0.5">
                      <Calendar className="w-3.5 h-3.5" /> {new Date(ord.createdAt).toLocaleString('vi-VN')}
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-bold text-gray-600">Trạng thái:</span>
                    <select
                      value={ord.status}
                      aria-label="Order Status"
                      onChange={(e) => handleChangeOrderStatus(ord.id, e.target.value as any)}
                      className={`px-3 py-1 font-bold text-xs border rounded-sm ${
                        ord.status === "Chờ xử lý" ? "bg-orange-50 border-orange-200 text-orange-700" :
                        ord.status === "Đã xác nhận" ? "bg-blue-50 border-blue-200 text-blue-700" :
                        ord.status === "Đang giao" ? "bg-indigo-50 border-indigo-200 text-indigo-700" :
                        ord.status === "Đã hoàn thành" ? "bg-green-50 border-green-200 text-green-700" :
                        "bg-red-50 border-red-200 text-red-700"
                      }`}
                    >
                      <option value="Chờ xử lý">Chờ xử lý</option>
                      <option value="Đã xác nhận">Đã xác nhận</option>
                      <option value="Đang giao">Đang giao</option>
                      <option value="Đã hoàn thành">Đã hoàn thành</option>
                      <option value="Đã hủy">Đã hủy (Đơn hỏng)</option>
                    </select>
                  </div>
                </div>

                {/* Shipping destination + Buyer credentials info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs bg-gray-50 p-3 border">
                  <div>
                    <h4 className="font-bold text-gray-800 mb-1.5 uppercase">Địa chỉ nhận hàng (Giao COD):</h4>
                    <p className="text-gray-900 font-medium">Họ tên: <strong className="font-extrabold text-[#E60012]">{ord.customerName}</strong></p>
                    <p className="text-gray-900">Số ĐT: <strong className="font-bold">{ord.customerPhone}</strong></p>
                    <p className="text-gray-900">Địa chỉ: {ord.customerAddress}</p>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 mb-1.5 uppercase">Chi tiết liên lạc:</h4>
                    <p className="text-gray-900">Thư điện tử (Email): {ord.customerEmail}</p>
                    <p className="text-gray-900 font-extrabold mt-2">Tổng hóa đơn: <span className="text-[#E60012] text-sm">{formatPrice(ord.totalAmount)}</span></p>
                  </div>
                </div>

                {/* Ordered line items */}
                <div className="space-y-2">
                  <p className="text-[10px] uppercase font-bold text-gray-400">Thiết bị đã chọn:</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {ord.items.map((item, idx) => (
                      <div key={idx} className="flex gap-2.5 items-center p-2 border border-gray-150">
                        <img src={item.image} alt={item.name} referrerPolicy="no-referrer" className="w-8 h-10 object-cover border shrink-0" />
                        <div className="min-w-0 flex-grow">
                          <p className="font-bold text-gray-900 truncate leading-snug">{item.name}</p>
                          <p className="text-[10px] text-gray-400">Size: {item.size} | Màu: {item.color} | SL: {item.quantity}</p>
                        </div>
                        <span className="font-bold shrink-0">{formatPrice(item.price * item.quantity)}</span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            ))}
            {orders.length === 0 && (
              <div className="text-center py-12 text-gray-400">Hệ thống chưa ghi nhận đơn đặt hàng nào từ người mua. Hãy thử đóng giả người dùng và đặt vài sản phẩm nhé!</div>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
