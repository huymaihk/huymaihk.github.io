import React, { useState } from 'react';
import { X, Mail, Lock, User as UserIcon, Shield, CheckCircle, AlertCircle, Sparkles } from 'lucide-react';
import { registerNewUser, loginUser } from '../firebase';
import { User } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: User) => void;
  initialTab?: "login" | "register";
}

export default function AuthModal({
  isOpen,
  onClose,
  onAuthSuccess,
  initialTab = "login"
}: AuthModalProps) {
  const [activeTab, setActiveTab] = useState<"login" | "register">(initialTab);
  
  // Registration and Login states
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"customer" | "admin">("customer");
  
  // Processing and alerts states
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ type: "success" | "error" | ""; text: string }>({ type: "", text: "" });

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback({ type: "", text: "" });

    // Validate
    if (!email.trim() || !password.trim()) {
      setFeedback({ type: "error", text: "Vui lòng nhập đầy đủ Email và Mật khẩu." });
      return;
    }

    if (activeTab === "register" && !name.trim()) {
      setFeedback({ type: "error", text: "Vui lòng nhập Họ & Tên của bạn." });
      return;
    }

    if (password.length < 6) {
      setFeedback({ type: "error", text: "Mật khẩu phải chứa ít nhất 6 ký tự để bảo mật." });
      return;
    }

    setIsLoading(true);
    try {
      if (activeTab === "login") {
        const loggedIn = await loginUser(email, password);
        setFeedback({ type: "success", text: `Đăng nhập thành công! Chào mừng ${loggedIn.name}.` });
        setTimeout(() => {
          onAuthSuccess(loggedIn);
          onClose();
        }, 1200);
      } else {
        const registered = await registerNewUser(name, email, password, role);
        setFeedback({ type: "success", text: "Đăng ký tài khoản thành công! Hãy đăng nhập ngay." });
        
        // Auto sign in or switch tab
        setName("");
        setPassword("");
        setActiveTab("login");
        setEmail(registered.email);
        setIsLoading(false);
      }
    } catch (err: any) {
      setFeedback({ type: "error", text: err.message || "Đã xảy ra sự cố trong quá trình xác thực." });
      setIsLoading(false);
    }
  };

  const handleQuickLogin = async (type: "admin" | "customer") => {
    const creds = type === "admin" 
      ? { email: "admin@camera.com", pass: "admin123" }
      : { email: "customer@gmail.com", pass: "123456" };

    setIsLoading(true);
    setFeedback({ type: "", text: "" });
    try {
      const loggedIn = await loginUser(creds.email, creds.pass);
      setFeedback({ type: "success", text: `Đã tự động kết nối tài khoản ${loggedIn.role === 'admin' ? 'Quản trị viên' : 'Khách hàng'}!` });
      setTimeout(() => {
        onAuthSuccess(loggedIn);
        onClose();
      }, 1000);
    } catch (err: any) {
      setFeedback({ type: "error", text: err.message });
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in" id="auth-modal-overlay">
      
      {/* Auth Container Card wrapper */}
      <div className="bg-white w-full max-w-md border-t-8 border-[#E60012] shadow-2xl relative overflow-hidden" id="auth-modal-card">
        
        {/* Header toolbar */}
        <div className="flex justify-between items-center px-6 pt-5 pb-3 border-b">
          <div className="flex items-center gap-2">
            <div className="bg-black text-white font-black text-[10px] p-1.5 leading-none">
              RETRO CAM
            </div>
            <h2 className="text-sm font-black tracking-tight text-gray-900 uppercase">
              Cổng Xác Thực Thành Viên
            </h2>
          </div>
          
          <button 
            type="button"
            onClick={onClose}
            className="text-gray-400 hover:text-black p-1 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selectors selectors */}
        <div className="flex border-b text-xs font-bold text-center bg-gray-50">
          <button
            type="button"
            onClick={() => { setActiveTab("login"); setFeedback({ type: "", text: "" }); }}
            className={`flex-1 py-3 border-r transition-colors ${
              activeTab === "login" 
                ? "bg-white text-[#E60012] border-b-2 border-b-[#E60012]" 
                : "text-gray-500 hover:text-black hover:bg-gray-100"
            }`}
          >
            ĐĂNG NHẬP
          </button>
          
          <button
            type="button"
            onClick={() => { setActiveTab("register"); setFeedback({ type: "", text: "" }); }}
            className={`flex-1 py-3 transition-colors ${
              activeTab === "register" 
                ? "bg-white text-[#E60012] border-b-2 border-b-[#E60012]" 
                : "text-gray-500 hover:text-black hover:bg-gray-100"
            }`}
          >
            ĐĂNG KÝ TÀI KHOẢN
          </button>
        </div>

        {/* Form Body section */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {feedback.text && (
            <div className={`p-3 text-[11px] font-bold flex items-start gap-2 ${
              feedback.type === "success" 
                ? "bg-green-50 border border-green-200 text-green-700" 
                : "bg-red-50 border border-red-200 text-red-700"
            }`}>
              {feedback.type === "success" ? (
                <CheckCircle className="w-4 h-4 shrink-0 text-green-500 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
              )}
              <span>{feedback.text}</span>
            </div>
          )}

          {/* Fully styled form inputs */}
          
          {activeTab === "register" && (
            <div>
              <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">
                Họ và Tên khách hàng
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                  <UserIcon className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  required
                  placeholder="Ví dụ: Nguyễn Văn A"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-gray-300 focus:outline-none focus:border-[#E60012] font-semibold"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">
              Địa chỉ Email (Tài khoản)
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                <Mail className="w-4 h-4" />
              </span>
              <input
                type="email"
                required
                placeholder="email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-gray-300 focus:outline-none focus:border-[#E60012] font-semibold"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">
              Mật khẩu truy cập
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                <Lock className="w-4 h-4" />
              </span>
              <input
                type="password"
                required
                minLength={6}
                placeholder="Tối thiểu 6 ký tự"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-gray-300 focus:outline-none focus:border-[#E60012] font-semibold"
              />
            </div>
          </div>

          {activeTab === "register" && (
            <div>
              <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">
                Phân quyền tài khoản
              </label>
              <div className="grid grid-cols-2 gap-2 mt-1">
                <button
                  type="button"
                  onClick={() => setRole("customer")}
                  className={`py-2 px-3 text-xs font-bold border flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                    role === "customer"
                      ? "border-[#E60012] bg-red-50 text-[#E60012]"
                      : "border-gray-200 text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  <UserIcon className="w-3.5 h-3.5" />
                  Khách Mua Hàng
                </button>
                <button
                  type="button"
                  onClick={() => setRole("admin")}
                  className={`py-2 px-3 text-xs font-bold border flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                    role === "admin"
                      ? "border-[#E60012] bg-red-50 text-[#E60012]"
                      : "border-gray-200 text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  <Shield className="w-3.5 h-3.5" />
                  Trưởng Cửa Hàng
                </button>
              </div>
            </div>
          )}

          {/* Action button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2.5 bg-[#E60012] hover:bg-black text-white text-xs font-black uppercase tracking-wider transition-colors disabled:bg-gray-300 cursor-pointer"
          >
            {isLoading 
              ? "Vui lòng đợi giây lát..." 
              : activeTab === "login" ? "KẾT NỐI HỆ THỐNG / ĐĂNG NHẬP" : "ĐĂNG KÝ THÀNH VIÊN MỚI"}
          </button>

          {/* Quick Demo logins block */}
          <div className="pt-3 border-t border-dashed text-center">
            <span className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wide block mb-2.5">
              💡 BẢN CHẠY THỬ NHANH (QUICK DEMO ACCOUNTS)
            </span>
            <div className="flex flex-col gap-1.5">
              <button
                type="button"
                onClick={() => handleQuickLogin("admin")}
                disabled={isLoading}
                className="text-[10.5px] bg-gray-900 text-white font-extrabold py-1.5 px-3 hover:bg-black transition-colors flex items-center justify-center gap-1.5 cursor-pointer rounded-xs"
              >
                <Shield className="w-3.5 h-3.5 text-amber-500" />
                Đăng Nhập Quản Trị Viên (Admin) Thử Nghiệm
              </button>
              <button
                type="button"
                onClick={() => handleQuickLogin("customer")}
                disabled={isLoading}
                className="text-[10.5px] bg-gray-100 text-gray-800 font-bold py-1.5 px-3 hover:bg-gray-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer rounded-xs border"
              >
                <UserIcon className="w-3.5 h-3.5 text-blue-500" />
                Đăng Nhập Khách Hàng (Customer) Thử Nghiệm
              </button>
            </div>
          </div>

        </form>
      </div>
    </div>
  );
}
