import React from 'react';
import { ShoppingBag, ShieldAlert, Heart, Search, Menu, Sparkles, User as UserIcon, LogOut } from 'lucide-react';
import { User } from '../types';

interface HeaderProps {
  activeCategory: "Tất cả" | "Máy Ảnh" | "Ống Kính" | "Phụ Kiện";
  setActiveCategory: (cat: "Tất cả" | "Máy Ảnh" | "Ống Kính" | "Phụ Kiện") => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  cartCount: number;
  onOpenCart: () => void;
  isAdminMode: boolean;
  setIsAdminMode: (admin: boolean) => void;
  isFirebaseEnabled: boolean;
  currentUser: User | null;
  onOpenAuthModal: (tab?: "login" | "register") => void;
  onLogout: () => void;
}

export default function Header({
  activeCategory,
  setActiveCategory,
  searchQuery,
  setSearchQuery,
  cartCount,
  onOpenCart,
  isAdminMode,
  setIsAdminMode,
  isFirebaseEnabled,
  currentUser,
  onOpenAuthModal,
  onLogout
}: HeaderProps) {
  return (
    <header id="uniqlo-header" className="sticky top-0 z-40 w-full bg-white border-b border-gray-200 shadow-xs">
      {/* Top Banner alert */}
      <div className="bg-[#E60012] text-white text-center py-1.5 px-4 text-xs font-medium tracking-wide flex justify-center items-center gap-2">
        <span>📷 Chợ Máy Ảnh Cũ Nhật Bản - Khảo sát số shot, kính đẹp không mốc rễ, bảo hành uy tín</span>
        <span className="hidden md:inline-flex items-center gap-1 bg-white/20 px-2 py-0.5 rounded text-[10px]">
          <Sparkles className="w-3 h-3" /> Hệ thống AI Đăng Thiết Bị Tự Động Đã Sẵn Sàng
        </span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <div className="flex items-center gap-4">
            <button 
              id="uniqlo-logo-btn"
              onClick={() => { setIsAdminMode(false); setActiveCategory("Tất cả"); }} 
              className="flex items-center select-none"
            >
              <div className="bg-black text-white flex flex-col justify-center items-center w-12 h-12 md:w-14 md:h-14 font-black text-xs leading-none tracking-tighter">
                <span>MÁY</span>
                <span>ẢNH</span>
              </div>
              <div className="hidden sm:flex flex-col ml-3 tracking-widest text-[#1C1917] font-sans font-bold">
                <span className="text-[10px] leading-none text-red-600 font-black">USED BOUTIQUE</span>
                <span className="text-xs md:text-sm leading-tight font-extrabold uppercase">Nhật Bản</span>
              </div>
            </button>
          </div>

          {/* Search bar & Admin Switch - Right panel */}
          <div className="flex items-center gap-2 md:gap-4 flex-1 max-w-md justify-end">
            <div className="relative w-full max-w-[200px] sm:max-w-[280px]">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                <Search className="w-4 h-4" />
              </span>
              <input
                id="header-search-input"
                type="text"
                placeholder="Tìm kiếm sản phẩm..."
                value={searchQuery}
                aria-label="Search"
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-1.5 md:py-2 text-xs md:text-sm bg-gray-50 border border-gray-300 rounded focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#E60012] focus:border-[#E60012] transition-all"
              />
            </div>

            {/* User Profile / Auth Button */}
            {currentUser ? (
              <div className="flex items-center gap-1.5 md:gap-2 bg-gray-50 border border-gray-200 p-1 md:py-1.5 md:px-2 rounded-xs">
                <div className="w-6 h-6 md:w-7 md:h-7 rounded-sm bg-[#E60012] text-white flex items-center justify-center text-xs font-black uppercase">
                  {currentUser.name.charAt(0)}
                </div>
                <div className="hidden md:flex flex-col text-left leading-tight shrink-0">
                  <span className="text-[10px] font-black text-gray-900 truncate max-w-[70px]">{currentUser.name}</span>
                  <span className="text-[8px] font-bold text-gray-500 uppercase tracking-wider">{currentUser.role === 'admin' ? 'Quản Trị' : 'Khách Hàng'}</span>
                </div>
                <button
                  type="button"
                  onClick={onLogout}
                  title="Đăng xuất tài khoản"
                  className="p-1 text-gray-400 hover:text-[#E60012] transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => onOpenAuthModal("login")}
                className="flex items-center gap-1.5 px-2.5 py-1.5 md:px-3 md:py-2 text-xs md:text-sm font-semibold border border-gray-300 text-gray-700 hover:bg-gray-100 hover:text-[#E60012] transition-all cursor-pointer bg-white rounded-xs"
              >
                <UserIcon className="w-4 h-4 text-gray-500" />
                <span>Đăng Nhập</span>
              </button>
            )}

            {/* Admin Toggle button with clean high contrast UI */}
            <button
              id="btn-admin-gate"
              onClick={() => {
                if (!currentUser) {
                  onOpenAuthModal("login");
                } else if (currentUser.role !== "admin") {
                  // Prompt to switch account
                  onLogout();
                  onOpenAuthModal("login");
                } else {
                  setIsAdminMode(!isAdminMode);
                }
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 md:px-3 md:py-2 text-xs md:text-sm font-semibold border rounded transition-all cursor-pointer ${
                isAdminMode
                  ? "bg-gray-900 border-gray-900 text-white hover:bg-gray-800"
                  : currentUser && currentUser.role === "admin"
                    ? "bg-amber-50 border-amber-300 text-amber-800 hover:bg-amber-100 ring-1 ring-amber-400/30"
                    : "bg-white border-gray-300 text-gray-700 hover:bg-gray-100"
              }`}
            >
              <ShieldAlert className="w-4 h-4 text-[#E60012]" />
              <span className="hidden sm:inline">
                {isAdminMode 
                  ? "Thoát Admin" 
                  : currentUser?.role === "admin" 
                    ? "Mở Bảng Admin" 
                    : "Admin Owner"}
              </span>
              <span className="sm:hidden">{isAdminMode ? "User" : "Admin"}</span>
            </button>

            {/* Shopping Cart Button */}
            <button
              id="btn-trigger-cart"
              onClick={onOpenCart}
              className="relative p-2 text-gray-700 hover:text-[#E60012] transition-colors cursor-pointer"
              aria-label="Toggle cart modal"
            >
              <ShoppingBag className="w-5 h-5 md:w-6 md:h-6" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#E60012] text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Central Department Filters Bar (Desktop and mobile inline) */}
        {!isAdminMode && (
          <div className="flex border-t border-gray-100 overflow-x-auto no-scrollbar">
            {["Tất cả", "Máy Ảnh", "Ống Kính", "Phụ Kiện"].map((cat) => {
              const works = cat as "Tất cả" | "Máy Ảnh" | "Ống Kính" | "Phụ Kiện";
              return (
                <button
                  id={`cat-filter-${works}`}
                  key={cat}
                  onClick={() => setActiveCategory(works)}
                  className={`px-4 py-3 text-xs md:text-sm font-bold tracking-wider relative whitespace-nowrap transition-colors cursor-pointer ${
                    activeCategory === works
                      ? "text-[#E60012]"
                      : "text-gray-600 hover:text-black"
                  }`}
                >
                  {cat === "Tất cả" ? "TẤT CẢ THIẾT BỊ" : cat.toUpperCase()}
                  {activeCategory === works && (
                    <div className="absolute bottom-0 left-4 right-4 h-0.5 bg-[#E60012]" />
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </header>
  );
}
