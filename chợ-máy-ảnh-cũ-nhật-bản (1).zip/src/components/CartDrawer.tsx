import React, { useState } from 'react';
import { CartItem, Order } from '../types';
import { X, Trash2, Plus, Minus, ShoppingBag, Truck, Contact2, CheckCircle } from 'lucide-react';
import { addLiveOrder } from '../firebase';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart
}: CartDrawerProps) {
  const [customerName, setCustomerName] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerAddress, setCustomerAddress] = useState("");

  const [isLoading, setIsLoading] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState<Order | null>(null);
  const [errorMsg, setErrorMsg] = useState("");

  if (!isOpen) return null;

  const formatPrice = (value: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value);
  };

  const calculateSubtotal = () => {
    return cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);
  };

  const subtotal = calculateSubtotal();
  const deliveryFee = subtotal > 1499000 || subtotal === 0 ? 0 : 39000; // Free delivery over 1.5M
  const grandTotal = subtotal + deliveryFee;

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    if (cartItems.length === 0) {
      setErrorMsg("Bạn chưa có sản phẩm nào trong giỏ đồ.");
      return;
    }

    if (!customerName.trim() || !customerEmail.trim() || !customerPhone.trim() || !customerAddress.trim()) {
      setErrorMsg("Vui lòng điền đầy đủ tất cả thông tin giao nhận hàng.");
      return;
    }

    setIsLoading(true);

    try {
      const orderItems = cartItems.map(item => ({
        productId: item.product.id,
        name: item.product.name,
        price: item.product.price,
        quantity: item.quantity,
        color: item.selectedColor.name,
        size: item.selectedSize,
        image: item.product.images[0]
      }));

      const payload = {
        customerName: customerName.trim(),
        customerEmail: customerEmail.trim(),
        customerPhone: customerPhone.trim(),
        customerAddress: customerAddress.trim(),
        items: orderItems,
        totalAmount: grandTotal,
        status: "Chờ xử lý" as const
      };

      const result = await addLiveOrder(payload);
      setOrderSuccess(result);
      onClearCart();
    } catch (e: any) {
      console.error(e);
      setErrorMsg("Có lỗi xảy ra khi gửi đơn hàng. Vui lòng thử lại.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" role="dialog" aria-modal="true">
      <div className="absolute inset-0 overflow-hidden">
        
        {/* Gray Backdrop curtain */}
        <div 
          onClick={onClose} 
          className="absolute inset-0 bg-black/60 transition-opacity backdrop-blur-xs" 
          aria-hidden="true" 
        />

        {/* Drawer slide-out alignment */}
        <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
          <div className="pointer-events-auto w-screen max-w-lg">
            <div className="flex h-full flex-col bg-white shadow-2xl border-l border-gray-100">
              
              {/* Drawer Title Header */}
              <div className="flex items-center justify-between px-4 py-6 sm:px-6 border-b border-gray-200">
                <h2 className="text-sm md:text-base font-extrabold text-gray-900 tracking-wider flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-[#E60012]" /> GIỎ ĐỒ CỦA BẠN ({cartItems.reduce((acc, i) => acc + i.quantity, 0)})
                </h2>
                <button
                  onClick={onClose}
                  className="p-1.5 text-gray-400 hover:text-black rounded-full hover:bg-gray-100"
                  aria-label="Close cart"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Success Screen */}
              {orderSuccess ? (
                <div className="flex-1 overflow-y-auto p-6 flex flex-col justify-center items-center text-center">
                  <CheckCircle className="w-16 h-16 text-[#E60012] mb-4 animate-bounce" />
                  <h3 className="text-lg font-black text-gray-900 mb-2">ĐẶT HÀNG THÀNH CÔNG!</h3>
                  <p className="text-xs text-gray-600 mb-6 max-w-sm">
                    Cảm ơn khách hàng **{orderSuccess.customerName}**. Đơn hàng mã số #{orderSuccess.id.split('_').pop()} trị giá **{formatPrice(orderSuccess.totalAmount)}** đang được tiếp nhận để xử lý.
                  </p>

                  <div className="bg-gray-50 border border-gray-200 p-4 text-left w-full text-xs space-y-2.5 rounded-sm">
                    <p className="font-bold text-gray-800">Thông tin nhận hàng:</p>
                    <p><span className="text-gray-400">Số ĐT:</span> {orderSuccess.customerPhone}</p>
                    <p><span className="text-gray-400">Địa chỉ:</span> {orderSuccess.customerAddress}</p>
                    <p><span className="text-gray-400">Trạng thái:</span> <span className="bg-orange-100 text-orange-800 px-2 py-0.5 font-bold rounded-sm inline-block">Chờ xử lý</span></p>
                  </div>

                  <p className="text-[11px] text-gray-500 mt-6 italic">
                    Chủ shop có thể xem và duyệt đơn này ngay tức thì trong tab trang Admin!
                  </p>

                  <button
                    onClick={() => { setOrderSuccess(null); onClose(); }}
                    className="mt-8 w-full bg-gray-900 hover:bg-black text-white font-black text-xs py-3.5 uppercase tracking-widest cursor-pointer"
                  >
                    Tiếp tục mua hàng
                  </button>
                </div>
              ) : (
                /* Dynamic Content List */
                <div className="flex-1 overflow-y-auto flex flex-col">
                  {cartItems.length === 0 ? (
                    <div className="flex-1 flex flex-col justify-center items-center p-8 text-center bg-gray-50/55">
                      <ShoppingBag className="w-12 h-12 text-gray-300 mb-3" />
                      <p className="text-sm font-bold text-gray-500">Giỏ đồ của bạn đang trống</p>
                      <p className="text-xs text-gray-400 mt-1 max-w-xs">Tuyển tập những mẫu đồ tối giản thiết kế cao cấp LifeWear từ UNIQLO đang chờ bạn khám phá.</p>
                      <button
                        onClick={onClose}
                        className="mt-6 bg-[#E60012] hover:bg-red-700 text-white font-extrabold text-xs py-3 px-6 tracking-wide uppercase transition-all"
                      >
                        Khám phá ngay
                      </button>
                    </div>
                  ) : (
                    <>
                      {/* Products Scroll Container */}
                      <div className="px-4 py-4 sm:px-6 space-y-4 max-h-[300px] overflow-y-auto border-b border-gray-100 bg-gray-50/50">
                        {cartItems.map((item) => (
                          <div key={item.id} className="flex items-center gap-4 bg-white p-3 border border-gray-200">
                            <img
                              src={item.product.images[0]}
                              alt={item.product.name}
                              referrerPolicy="no-referrer"
                              className="w-14 h-18 object-cover shrink-0 border border-gray-100"
                            />
                            
                            <div className="flex-grow min-w-0">
                              <h4 className="text-xs font-bold text-gray-900 truncate leading-tight">
                                {item.product.name}
                              </h4>
                              <p className="text-[10px] text-gray-400 mt-0.5 space-x-2">
                                <span>Size: <strong className="text-gray-700">{item.selectedSize}</strong></span>
                                <span>Màu: <strong className="text-gray-700">{item.selectedColor.name}</strong></span>
                              </p>

                              <div className="flex justify-between items-center mt-2">
                                <div className="flex items-center border border-gray-300 rounded overflow-hidden scale-90 -ml-2">
                                  <button
                                    onClick={() => onUpdateQuantity(item.id, -1)}
                                    className="px-2 py-1 bg-gray-50 hover:bg-gray-150"
                                  >
                                    <Minus className="w-3 h-3" />
                                  </button>
                                  <span className="px-3 text-xs font-bold">{item.quantity}</span>
                                  <button
                                    onClick={() => onUpdateQuantity(item.id, 1)}
                                    className="px-2 py-1 bg-gray-50 hover:bg-gray-150"
                                  >
                                    <Plus className="w-3 h-3" />
                                  </button>
                                </div>
                                <span className="text-xs font-extrabold text-gray-900">
                                  {formatPrice(item.product.price * item.quantity)}
                                </span>
                              </div>
                            </div>

                            <button
                              onClick={() => onRemoveItem(item.id)}
                              className="p-1 text-gray-400 hover:text-[#E60012] shrink-0"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>

                      {/* Client Delivery Details Form */}
                      <form onSubmit={handleCheckout} className="p-4 sm:p-6 border-b border-gray-200 bg-white">
                        <h3 className="text-xs font-bold text-gray-900 uppercase tracking-widest flex items-center gap-1.5 mb-4">
                          <Contact2 className="w-4 h-4 text-[#E60012]" /> 1. Thông Tin Nhận Hàng (Giao Tận Nơi)
                        </h3>

                        <div className="space-y-3">
                          <div>
                            <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Họ và tên khách hàng *</label>
                            <input
                              type="text"
                              value={customerName}
                              onChange={(e) => setCustomerName(e.target.value)}
                              placeholder="Ví dụ: Nguyễn Văn A"
                              required
                              className="w-full text-xs px-3 py-2 border border-gray-300 rounded focus:border-[#E60012] focus:outline-none bg-gray-50/50"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Số điện thoại *</label>
                              <input
                                type="tel"
                                value={customerPhone}
                                onChange={(e) => setCustomerPhone(e.target.value)}
                                placeholder="0901234567"
                                required
                                className="w-full text-xs px-3 py-2 border border-gray-300 rounded focus:border-[#E60012] focus:outline-none bg-gray-50/50"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Email liên lạc *</label>
                              <input
                                type="email"
                                value={customerEmail}
                                onChange={(e) => setCustomerEmail(e.target.value)}
                                placeholder="name@domain.com"
                                required
                                className="w-full text-xs px-3 py-2 border border-gray-300 rounded focus:border-[#E60012] focus:outline-none bg-gray-50/50"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Địa chỉ giao hàng chi tiết *</label>
                            <textarea
                              value={customerAddress}
                              onChange={(e) => setCustomerAddress(e.target.value)}
                              rows={2}
                              placeholder="Số nhà, Tên đường, Phường/Xã, Quận/Huyện, Tỉnh/Thành phố"
                              required
                              className="w-full text-xs px-3 py-2 border border-gray-300 rounded focus:border-[#E60012] focus:outline-none bg-gray-50/50"
                            />
                          </div>
                        </div>
                      </form>

                      {/* Summary calculations & checkout submit button */}
                      <div className="mt-auto p-4 sm:p-6 bg-gray-50 space-y-4">
                        <div className="text-xs space-y-2">
                          <div className="flex justify-between text-gray-500">
                            <span>Tạm tính:</span>
                            <span className="font-bold text-gray-800">{formatPrice(subtotal)}</span>
                          </div>
                          <div className="flex justify-between text-gray-500 items-center">
                            <span className="flex items-center gap-1">
                              <Truck className="w-3.5 h-3.5 text-gray-400" /> Phí vận chuyển:
                            </span>
                            <span className={deliveryFee === 0 ? "text-green-600 font-extrabold" : "font-bold text-gray-800"}>
                              {deliveryFee === 0 ? "MIỄN PHÍ" : formatPrice(deliveryFee)}
                            </span>
                          </div>
                          {deliveryFee > 0 && (
                            <p className="text-[10px] text-gray-400 italic">
                              Hóa đơn từ **1.500.000 ₫** được Miễn phí giao hàng toàn quốc!
                            </p>
                          )}
                          <div className="border-t border-gray-200 mt-2 pt-2 flex justify-between text-sm font-extrabold text-gray-900">
                            <span>TỔNG THANH TOÁN (COD):</span>
                            <span className="text-base text-[#E60012]">{formatPrice(grandTotal)}</span>
                          </div>
                        </div>

                        {errorMsg && (
                          <p className="text-xs text-red-500 font-semibold mb-2 bg-red-50 p-2 border-l-4 border-red-500">
                            {errorMsg}
                          </p>
                        )}

                        <button
                          type="button"
                          onClick={handleCheckout}
                          disabled={isLoading}
                          className="w-full bg-[#E60012] hover:bg-red-700 text-white font-extrabold text-xs py-4 tracking-wider uppercase transition-colors flex items-center justify-center gap-2 shadow-sm cursor-pointer disabled:bg-gray-400"
                        >
                          {isLoading ? "Đang xử lý đặt đơn..." : "XÁC NHẬN ĐẶT HÀNG (COD)"}
                        </button>
                      </div>
                    </>
                  )}
                </div>
              )}

            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
