import { Product } from "./types";

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: "camera-p1",
    name: "Sony Alpha 7 Mark III (Sony A7 III) - Đã qua sử dụng",
    price: 24500000,
    originalPrice: 28900000,
    category: "Máy Ảnh",
    subcategory: "Mirrorless",
    description: "Sony A7 III được mệnh danh là 'ông vua đa dụng' trong phân khúc Full-Frame Mirrorless cũ. Với cảm biến 24.2 MP, chống rung 5 trục hoàn hảo và khả năng lấy nét tự động Eye-AF cực nhanh, mẫu máy này là lựa chọn số 1 cho các nhiếp ảnh gia dịch vụ, chụp sự kiện hoặc quay phim nghệ thuật tại Việt Nam.",
    images: [
      "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=500&q=80"
    ],
    sizes: ["Chỉ Body (95%)", "Body Đẹp (99%)", "Kèm Kit 28-70mm"],
    colors: [
      { name: "Đen Nhám (Matte Black)", code: "#18181B" }
    ],
    seoTitle: "Mua Máy Ảnh Sony A7 III Cũ Giá Rẻ 99% Chính Hãng HN TPHCM | Máy Ảnh Cũ Nhật Bản",
    seoDescription: "Chuyên mua bán Sony Alpha 7 Mark III (A7M3) cũ xách tay, chính hãng bảo hành uy tín. Cảm biến Full-Frame 24.2MP, chống rung 5 trục, quay 4K chất lượng cao.",
    seoKeywords: "sony a7 iii cũ, sony a7m3, máy ảnh mirrorless cũ, mua sony a73 cũ, máy ảnh cũ nhật bản",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "camera-p2",
    name: "Canon EOS 5D Mark III - Huyền thoại chân dung",
    price: 11200000,
    originalPrice: 13500000,
    category: "Máy Ảnh",
    subcategory: "DSLR",
    description: "Huyền thoại chụp ảnh chân dung và sự kiện cưới tại Việt Nam. Canon 5D Mark III sở hữu cảm biến Full-Frame cho ra chất màu ấm áp đặc trưng, nịnh mắt cho ảnh chân dung ngoài trời. Khung vỏ hợp kim magnesium siêu bền bỉ thách thức mọi thời tiết khắc nghiệt.",
    images: [
      "https://images.unsplash.com/photo-1616440347437-b1c73416efc2?auto=format&fit=crop&w=500&q=80"
    ],
    sizes: ["Cũ xước nhẹ (90%)", "Khá mới 30k shot (95%)", "Siêu đẹp 5k shot (99%)"],
    colors: [
      { name: "Đen Cổ Điển", code: "#27272A" }
    ],
    seoTitle: "Máy Ảnh Canon EOS 5D Mark III Cũ Giá Tốt, Bảo Hành 12 Tháng | Máy Ảnh Cũ",
    seoDescription: "Bán Canon 5D Mark III (5D3) giá rẻ nhất thị trường. Máy bền bỉ chuyên nghiệp chụp chân dung xóa phông cưới hỏi, bảo hành dài hạn tặng phụ kiện.",
    seoKeywords: "canon 5d mark iii cũ, canon 5d3 cũ, máy ảnh dslr canon cũ, ảnh chân dung xóa phông",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "camera-p3",
    name: "Fujifilm X-T3 - Vintage & Giả lập màu phim",
    price: 16900000,
    originalPrice: 18500000,
    category: "Máy Ảnh",
    subcategory: "Mirrorless",
    description: "Chiếc máy chụp ảnh mang đậm phong cách vintage hoài cổ với hệ màu phim trứ danh được giới trẻ Việt Nam vô cùng săn lùng. Fujifilm X-T3 sở hữu cảm biến APS-C X-Trans CMOS 4 và bộ xử lý X-Processor 4 cực mạnh, cho khả năng giả lập phim Classic Chrome, Velvia rực rỡ trực tiếp mà không cần hậu kỳ.",
    images: [
      "https://images.unsplash.com/photo-1502982720700-bfff97f2ecac?auto=format&fit=crop&w=500&q=80"
    ],
    sizes: ["Body Đẹp 97%", "Like New 99%", "Kèm Lens 18-55mm f2.8-4"],
    colors: [
      { name: "Sắc Bạc Retro", code: "#D4D4D8" },
      { name: "Đen Carbon Matte", code: "#09090B" }
    ],
    seoTitle: "Fujifilm X-T3 Cũ Gọn Nhẹ Giả Lập Màu Phim Tuyệt Đẹp | Máy Ảnh Cũ",
    seoDescription: "Máy ảnh Fujifilm X-T3 cũ đẹp chính hãng giá tốt. Hỗ trợ quay phim 4K 60fps chuyên nghiệp, thiết kế cơ học hoài cổ tinh tế đầy lôi cuốn.",
    seoKeywords: "fujifilm x-t3 cũ, fujifilm xt3 cũ, máy ảnh giả lập màu phim, chụp ảnh vintage, fuji xt3 giá rẻ",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "camera-p4",
    name: "Ống Kính Canon EF 50mm f/1.8 STM - Chân dung quốc dân",
    price: 1950000,
    originalPrice: 2450000,
    category: "Ống Kính",
    subcategory: "Lens Fix (Prime)",
    description: "Được mệnh danh là 'ống kính quốc dân' dành cho mọi người mới tập chụp ảnh chân dung xóa phông. Khẩu độ lớn f/1.8 giúp chụp thiếu sáng vượt trội và làm mờ phông nền mịn màng, làm nổi bật chủ thể chính sắc nét.",
    images: [
      "https://images.unsplash.com/photo-1617005082133-548c4dd27f35?auto=format&fit=crop&w=500&q=80"
    ],
    sizes: ["Like New (99%)", "Khá Mới (95%)"],
    colors: [
      { name: "Đen", code: "#1C1917" }
    ],
    seoTitle: "Lens Canon 50mm f/1.8 STM Cũ Giá Rẻ Chân Dung Xóa Phông | Máy Ảnh Cũ",
    seoDescription: "Bán ống kính chân dung quốc dân Canon EF 50mm F1.8 STM cũ hàng đẹp không mốc xước rễ tre. Đầy đủ cáp trước cáp sau, hỗ trợ lấy nét êm ái.",
    seoKeywords: "canon 50mm f1.8 stm cũ, lens canon 50 f1.8, ống kính chân dung giá rẻ, xóa phông canon",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "camera-p5",
    name: "Ống Kính Sony FE 85mm f/1.8 - Đỉnh Cao Xóa Phông Chuyên Nghiệp",
    price: 7800000,
    originalPrice: 8900000,
    category: "Ống Kính",
    subcategory: "Lens Fix (Prime)",
    description: "Ống kính chân dung chuyên nghiệp dành cho hệ máy ảnh Sony Alpha Full-Frame. Tiêu cự 85mm cùng 9 lá khẩu tròn cho hiệu ứng bokeh tròn trịa lung linh, mô-tơ lấy nét tuyến tính kép siêu nhanh và êm ái lý tưởng cho cả chụp ảnh nghệ thuật lẫn quay video.",
    images: [
      "https://images.unsplash.com/photo-1607462109225-6b64ae2dd3cb?auto=format&fit=crop&w=500&q=80"
    ],
    sizes: ["Hàng Lướt Đẹp 99%", "Cũ Đã Qua Sử Dụng (90%)"],
    colors: [
      { name: "Đen Sơn Tĩnh Điện", code: "#111827" }
    ],
    seoTitle: "Lens Sony FE 85mm f/1.8 Cũ Rất Đẹp Không Mốc Rễ | Máy Ảnh Cũ",
    seoDescription: "Đại lý bán lens cũ Sony FE 85 f1.8 cũ chất lượng cao thích hợp chụp ảnh ngoại cảnh chân dung xóa mù mịt. Giá cả ưu đãi, bao test hoàn tiền 7 ngày.",
    seoKeywords: "sony 85mm f1.8 cũ, lens sony 85 f1.8, ống kính chân dung sony cũ, fe 85mm 1.8 lướt",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "camera-p6",
    name: "Thẻ Nhớ SDXC SanDisk Extreme Pro 128GB 170MB/s V30",
    price: 490000,
    originalPrice: 650000,
    category: "Phụ Kiện",
    subcategory: "Thẻ nhớ",
    description: "Dòng thẻ nhớ hiệu năng cao chuyên dụng cho quay video 4K UHD và chụp ảnh liên tục tốc độ cao trên các dòng DSLR và Mirrorless đời mới. Tốc độ đọc lên đến 170MB/s giúp tối ưu hóa luồng công việc chụp ảnh và truy xuất dữ liệu nhanh chóng.",
    images: [
      "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=500&q=80"
    ],
    sizes: ["64GB UHS-I", "128GB UHS-I", "256GB UHS-I"],
    colors: [
      { name: "Đỏ Đen SanDisk", code: "#7F1D1D" }
    ],
    seoTitle: "Thẻ Nhớ SanDisk Extreme Pro 128GB Cũ Hỗ Trợ Quay 4K | Phụ Kiện Máy Ảnh",
    seoDescription: "Bán thẻ nhớ SD SanDisk Extreme Pro 128GB tốc độ cao 170MB/s chính hãng cũ chất lượng cao dã ngoại thể thao quay phim không giật lag.",
    seoKeywords: "thẻ nhớ máy ảnh, sandisk extreme pro 128gb, thẻ nhớ sd 128gb cũ, phụ kiện máy ảnh cũ",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];
