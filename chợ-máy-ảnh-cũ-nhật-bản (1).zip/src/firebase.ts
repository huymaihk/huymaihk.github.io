import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { getFirestore, doc, getDoc, collection, getDocs, deleteDoc, setDoc, updateDoc, query, orderBy } from 'firebase/firestore';
import firebaseConfig from './firebase-applet-config.json';
import { Product, Order, User } from "./types";
import { INITIAL_PRODUCTS } from "./catalog";

let app: any = null;
let db: any = null;
let auth: any = null;
let isFirebaseEnabled = false;

// Authenticate setup integrity at module level
if (firebaseConfig && firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.apiKey !== "") {
  try {
    app = initializeApp(firebaseConfig);
    db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
    auth = getAuth(app);
    isFirebaseEnabled = true;
    console.log("Firebase initialized successfully on client");
  } catch (error) {
    console.error("Firebase startup issues detected. Defaulting to Local Storage Core:", error);
  }
}

export { db, auth, isFirebaseEnabled };

// Standardized operation enumerator required by Firebase specifications
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

// Required strict error reporting utility
export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid || null,
      email: auth?.currentUser?.email || null,
      emailVerified: auth?.currentUser?.emailVerified || null,
      isAnonymous: auth?.currentUser?.isAnonymous || null,
      tenantId: auth?.currentUser?.tenantId || null,
      providerInfo: auth?.currentUser?.providerData?.map((provider: any) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error Payload: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const LOCAL_PRODUCTS_KEY = "uniqlo_local_products";
const LOCAL_ORDERS_KEY = "uniqlo_local_orders";

// Live async wrappers to enable real/local execution transparently
export async function getLiveProducts(): Promise<Product[]> {
  if (!isFirebaseEnabled) {
    const stored = localStorage.getItem(LOCAL_PRODUCTS_KEY);
    if (stored) return JSON.parse(stored);
    localStorage.setItem(LOCAL_PRODUCTS_KEY, JSON.stringify(INITIAL_PRODUCTS));
    return INITIAL_PRODUCTS;
  }

  try {
    const productsCol = collection(db, 'products');
    const q = query(productsCol, orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    const list: Product[] = [];
    
    snapshot.forEach((docRef) => {
      const data = docRef.data();
      list.push({ ...data, id: docRef.id } as Product);
    });

    if (list.length === 0) {
      // Lazy seed to cloud database to start with gorgeous mock elements
      for (const item of INITIAL_PRODUCTS) {
        await setDoc(doc(db, 'products', item.id), item);
      }
      return INITIAL_PRODUCTS;
    }
    return list;
  } catch (error) {
    console.error("Firestore loading failure. Reverting to persistent Local storage:", error);
    const stored = localStorage.getItem(LOCAL_PRODUCTS_KEY);
    return stored ? JSON.parse(stored) : INITIAL_PRODUCTS;
  }
}

export async function addLiveProduct(product: Omit<Product, "id" | "createdAt" | "updatedAt">): Promise<Product> {
  const newProduct: Product = {
    ...product,
    id: "prod_" + Date.now().toString(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  if (isFirebaseEnabled) {
    try {
      const docRef = doc(db, 'products', newProduct.id);
      await setDoc(docRef, newProduct);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `products/${newProduct.id}`);
    }
  }

  // Double sync local storage
  const current = localStorage.getItem(LOCAL_PRODUCTS_KEY);
  const list: Product[] = current ? JSON.parse(current) : INITIAL_PRODUCTS;
  const updated = [newProduct, ...list];
  localStorage.setItem(LOCAL_PRODUCTS_KEY, JSON.stringify(updated));

  return newProduct;
}

export async function updateLiveProduct(product: Product): Promise<Product> {
  const updatedProduct: Product = {
    ...product,
    updatedAt: new Date().toISOString()
  };

  if (isFirebaseEnabled) {
    try {
      const docRef = doc(db, 'products', updatedProduct.id);
      await setDoc(docRef, updatedProduct);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `products/${updatedProduct.id}`);
    }
  }

  // Local storage sync
  const current = localStorage.getItem(LOCAL_PRODUCTS_KEY);
  const list: Product[] = current ? JSON.parse(current) : INITIAL_PRODUCTS;
  const updated = list.map(item => item.id === updatedProduct.id ? updatedProduct : item);
  localStorage.setItem(LOCAL_PRODUCTS_KEY, JSON.stringify(updated));

  return updatedProduct;
}

export async function deleteLiveProduct(id: string): Promise<boolean> {
  if (isFirebaseEnabled) {
    try {
      const docRef = doc(db, 'products', id);
      await deleteDoc(docRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `products/${id}`);
    }
  }

  const current = localStorage.getItem(LOCAL_PRODUCTS_KEY);
  const list: Product[] = current ? JSON.parse(current) : INITIAL_PRODUCTS;
  const filtered = list.filter(item => item.id !== id);
  localStorage.setItem(LOCAL_PRODUCTS_KEY, JSON.stringify(filtered));

  return true;
}

export async function getLiveOrders(): Promise<Order[]> {
  if (!isFirebaseEnabled) {
    const stored = localStorage.getItem(LOCAL_ORDERS_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  try {
    const ordersCol = collection(db, 'orders');
    const snapshot = await getDocs(ordersCol);
    const list: Order[] = [];
    
    snapshot.forEach((docRef) => {
      const data = docRef.data();
      list.push({ ...data, id: docRef.id } as Order);
    });

    return list.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (error) {
    console.error("Firestore loading failure for orders:", error);
    const stored = localStorage.getItem(LOCAL_ORDERS_KEY);
    return stored ? JSON.parse(stored) : [];
  }
}

export async function addLiveOrder(order: Omit<Order, "id" | "createdAt">): Promise<Order> {
  const newOrder: Order = {
    ...order,
    id: "ord_" + Date.now().toString(),
    createdAt: new Date().toISOString()
  };

  if (isFirebaseEnabled) {
    try {
      const docRef = doc(db, 'orders', newOrder.id);
      await setDoc(docRef, newOrder);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `orders/${newOrder.id}`);
    }
  }

  const current = localStorage.getItem(LOCAL_ORDERS_KEY);
  const list: Order[] = current ? JSON.parse(current) : [];
  const updated = [newOrder, ...list];
  localStorage.setItem(LOCAL_ORDERS_KEY, JSON.stringify(updated));

  return newOrder;
}

export async function updateOrderStatus(orderId: string, status: Order["status"]): Promise<boolean> {
  if (isFirebaseEnabled) {
    try {
      const docRef = doc(db, 'orders', orderId);
      await updateDoc(docRef, { status });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
    }
  }

  const current = localStorage.getItem(LOCAL_ORDERS_KEY);
  if (current) {
    const list: Order[] = JSON.parse(current);
    const updated = list.map(item => item.id === orderId ? { ...item, status } : item);
    localStorage.setItem(LOCAL_ORDERS_KEY, JSON.stringify(updated));
  }

  return true;
}

// --- USER AUTHENTICATION & REGISTRATION SYSTEM ---
const LOCAL_USERS_KEY = "uniqlo_local_users";
const SESSION_USER_KEY = "uniqlo_session_user";

// Pre-seeded local users to enable seamless testing of normal and admin accounts
const SEED_USERS: (User & { passwordText: string })[] = [
  {
    id: "admin_1",
    name: "Quản trị viên UNIQLO",
    email: "admin@uniqlo.com",
    role: "admin",
    passwordText: "admin123",
    createdAt: new Date().toISOString()
  },
  {
    id: "customer_1",
    name: "Nguyễn Văn A",
    email: "customer@gmail.com",
    role: "customer",
    passwordText: "123456",
    createdAt: new Date().toISOString()
  }
];

export async function registerNewUser(name: string, email: string, password: string, role: "customer" | "admin" = "customer"): Promise<User> {
  const normEmail = email.trim().toLowerCase();
  
  if (isFirebaseEnabled) {
    try {
      // 1. Create firebase auth credential
      const userCredential = await createUserWithEmailAndPassword(auth, normEmail, password);
      const uid = userCredential.user.uid;
      
      const newUser: User = {
        id: uid,
        name: name.trim(),
        email: normEmail,
        role: role,
        createdAt: new Date().toISOString()
      };
      
      // 2. Put record to Firestore Database
      const userDocRef = doc(db, 'users', uid);
      await setDoc(userDocRef, newUser);
      
      // Sync local storage copy
      const localUsers = getLocalUsers();
      localUsers.push({ ...newUser, passwordText: password });
      localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(localUsers));
      
      return newUser;
    } catch (error: any) {
      console.error("Firebase Auth registration failed. Using localized signup fallback.", error);
      throw error;
    }
  }

  // Local signup mode
  const localUsers = getLocalUsers();
  if (localUsers.some(u => u.email.toLowerCase() === normEmail)) {
    throw new Error("Email này đã được đăng ký trên website!");
  }

  const newUser: User = {
    id: "u_" + Date.now().toString(),
    name: name.trim(),
    email: normEmail,
    role: role,
    createdAt: new Date().toISOString()
  };

  localUsers.push({ ...newUser, passwordText: password });
  localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(localUsers));
  return newUser;
}

export async function loginUser(email: string, password: string): Promise<User> {
  const normEmail = email.trim().toLowerCase();

  if (isFirebaseEnabled) {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, normEmail, password);
      const uid = userCredential.user.uid;
      
      // Fetch user profile from Firestore Database
      const userDocRef = doc(db, 'users', uid);
      const docSnap = await getDoc(userDocRef);
      
      if (docSnap.exists()) {
        const userData = docSnap.data() as User;
        localStorage.setItem(SESSION_USER_KEY, JSON.stringify(userData));
        return userData;
      } else {
        // Fallback user profile creation if user exists in Auth but not in Firestore
        const newUser: User = {
          id: uid,
          name: email.split("@")[0],
          email: normEmail,
          role: normEmail.includes("admin") ? "admin" : "customer",
          createdAt: new Date().toISOString()
        };
        await setDoc(userDocRef, newUser);
        localStorage.setItem(SESSION_USER_KEY, JSON.stringify(newUser));
        return newUser;
      }
    } catch (error) {
      console.error("Firebase auth login failure. Checking localized user list fallback...", error);
      throw error;
    }
  }

  // Local login mode matching
  const localUsers = getLocalUsers();
  const matchedUser = localUsers.find(u => u.email.toLowerCase() === normEmail && u.passwordText === password);
  
  if (!matchedUser) {
    throw new Error("Email hoặc mật khẩu chưa chính xác. Vui lòng thử lại!");
  }

  const userCopy: User = {
    id: matchedUser.id,
    name: matchedUser.name,
    email: matchedUser.email,
    role: matchedUser.role,
    createdAt: matchedUser.createdAt
  };

  localStorage.setItem(SESSION_USER_KEY, JSON.stringify(userCopy));
  return userCopy;
}

export async function logoutUser(): Promise<void> {
  if (isFirebaseEnabled) {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Firebase Auth signout error", error);
    }
  }
  localStorage.removeItem(SESSION_USER_KEY);
}

export function getSessionUser(): User | null {
  const data = localStorage.getItem(SESSION_USER_KEY);
  if (!data) return null;
  try {
    return JSON.parse(data);
  } catch (e) {
    return null;
  }
}

// Helper to access local users list with initial seeding
function getLocalUsers(): Array<User & { passwordText: string }> {
  const stored = localStorage.getItem(LOCAL_USERS_KEY);
  if (stored) {
    try {
       return JSON.parse(stored);
    } catch (e) {
       return SEED_USERS;
    }
  }
  localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(SEED_USERS));
  return SEED_USERS;
}

